import asyncio,os,importlib,json,subprocess,math
from pathlib import Path
import edge_tts
m=importlib.import_module('edge_tts.communicate'); m._SSL_CTX.load_verify_locations(cafile=os.environ['NODE_EXTRA_CA_CERTS'])
root=Path(__file__).parent; pub=root/'public'
scenes=[
('question','BÌNH AN','Ai cũng khao khát bình an. Nhưng bình an có thật sự đến dễ dàng? Hay đó là kết quả của một hành trình thức tỉnh và trưởng thành?'),
('ratio','1% / 99%','Lời khuyên chỉ là một phần nhỏ. Phần lớn sự thức tỉnh đến từ những điều ta tự mình trải qua. Có những điều, chỉ khi đi qua rồi, ta mới hiểu.'),
('fracture','ĐI QUA ĐAU THƯƠNG','Trưởng thành thường đi cùng đau thương. Nhưng những vết nứt không chỉ làm ta tổn thương. Chúng còn mở ra một cách nhìn mới về cuộc đời.'),
('teachers','BA NGƯỜI THẦY','Một cái ví rỗng. Một lần thất bại. Một người rời đi. Những người thầy khắc nghiệt ấy dạy ta nỗ lực, kiên cường, và cách buông bỏ.'),
('stairs','ĐỨNG DẬY','Ta không lớn lên chỉ nhờ thời gian. Ta lớn lên từ những lần ngã xuống, rồi chọn đứng dậy và bước tiếp.'),
('accept','CHẤP NHẬN','Trưởng thành còn là học cách chấp nhận. Chấp nhận chia ly, thất bại, và những điều bất như ý. Chấp nhận rằng cuộc sống không hoàn hảo, để lòng mình thôi giằng co.'),
('orbits','MỖI NGƯỜI MỘT LỐI','Mỗi người có khát khao và con đường riêng. Đừng sống thay kỳ vọng của người khác. Cũng đừng buộc ai phải sống theo khuôn mẫu của mình.'),
('freedom','TỰ DO LÀ CHÍNH MÌNH','Tôn trọng sự khác biệt. Để mỗi tâm hồn được tự do là chính mình. Khi thôi cố kiểm soát mọi thứ, ta mới có chỗ cho bình yên.'),
('direction','BIẾT MÌNH ĐI ĐÂU','Có hai điều đưa ta đến gần hạnh phúc. Một là biết mình đang đi đâu: có mục tiêu, có phương hướng, và đủ kiên trì để bước qua gian khó.'),
('stillness','AN YÊN Ở HIỆN TẠI','Hai là biết an yên với hiện tại. Vừa rõ điều mình hướng tới, vừa trân trọng nơi mình đang đứng. Đó là một cách sống trọn vẹn.'),
('dawn','TRỞ VỀ VỚI CHÍNH MÌNH','Hãy để mỗi bước đi là một bài học. Mỗi đau thương là một bước ngoặt. Và mỗi ngày trôi qua, là một cơ hội trở về với chính mình. Bình an, từ đó mà lớn lên.')]
beat=60/88; fps=30
async def generate(i,s):
 path=pub/f'voice-{i:02d}.mp3'; words=[]
 c=edge_tts.Communicate(s[2],voice='vi-VN-NamMinhNeural',boundary='WordBoundary',proxy=os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy'))
 with path.open('wb') as f:
  async for chunk in c.stream():
   if chunk['type']=='audio': f.write(chunk['data'])
   elif chunk['type']=='WordBoundary': words.append({'text':chunk['text'],'start':chunk['offset']/1e7,'end':(chunk['offset']+chunk['duration'])/1e7})
 dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(path)],text=True))
 return dict(kind=s[0],title=s[1],text=s[2],audio=path.name,voiceDuration=dur,words=words)
async def main():
 result=[]
 for i,s in enumerate(scenes):
  cache=pub/f'voice-{i:02d}.json'
  if cache.exists(): r=json.loads(cache.read_text())
  else:
   for attempt in range(5):
    try:
     r=await generate(i,s); cache.write_text(json.dumps(r,ensure_ascii=False)); break
    except Exception as exc:
     print('Retry',i,attempt,type(exc).__name__,flush=True)
     if attempt==4: raise
     await asyncio.sleep(1.5)
  result.append(r); print(i,r['kind'],r['voiceDuration'],len(r['words']),flush=True)
 cur=0
 for r in result:
  r['startFrame']=cur; r['voiceOffsetFrames']=15
  r['durationFrames']=math.ceil((r['voiceDuration']+.95)/beat)*round(beat*fps) # corrected below to cumulative frame rounding
  r['durationFrames']=round(math.ceil((r['voiceDuration']+.95)/beat)*beat*fps)
  cur+=r['durationFrames']
 data={'fps':30,'width':1080,'height':1920,'bpm':88,'durationInFrames':cur,'scenes':result}
 (pub/'story.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
 (root/'SCRIPT.md').write_text('# BÌNH AN — lời đọc mới\n\nBiên tập từ thông điệp của video người dùng cung cấp; không sử dụng hình ảnh, footage hoặc âm thanh gốc.\n\n'+'\n\n'.join(f'## {i+1}. {s[1]}\n\n{s[2]}' for i,s in enumerate(scenes)))
 print('TOTAL',cur/30,flush=True)
asyncio.run(main())
