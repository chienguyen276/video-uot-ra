import React, {CSSProperties, useEffect, useState} from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, interpolate, Easing, delayRender, continueRender, cancelRender} from 'remotion';
import story from '../public/story.json';

const C={ink:'#11151E',paper:'#F3ECDD',amber:'#FFB570',blue:'#748BF0',slate:'#899099'};
const clamp=(v:number)=>Math.max(0,Math.min(1,v));
const out=(v:number)=>1-Math.pow(1-clamp(v),4);
const smooth=(v:number)=>{v=clamp(v);return v*v*(3-2*v)};
const lerp=(a:number,b:number,p:number)=>a+(b-a)*p;
type Scene=typeof story.scenes[number];
const enter=(t:number,d=0,dur=.7)=>out((t-d)/dur);
const wob=(t:number,k=1)=>Math.sin(t*k);
const Text:React.FC<{children:React.ReactNode,x?:number,y:number,size?:number,color?:string,weight?:number,align?:'left'|'center',width?:number,style?:CSSProperties}>=({children,x=110,y,size=104,color=C.paper,weight=800,align='left',width=830,style={}})=><div style={{position:'absolute',left:x,top:y,width,fontSize:size,fontWeight:weight,color,lineHeight:1.12,letterSpacing:'-.045em',textAlign:align,...style}}>{children}</div>;
const Reveal:React.FC<{lines:string[],t:number,delay?:number,y?:number,size?:number,color?:string,center?:boolean}>=({lines,t,delay=0,y=330,size=104,color=C.paper,center=false})=><>{lines.map((line,i)=>{const p=enter(t,delay+i*.08);return <Text key={i} y={y+i*size*1.15} size={size} color={color} align={center?'center':'left'} style={{opacity:p,transform:`translateY(${(1-p)*52}px)`}}>{line}</Text>})}</>;
const SVG:React.FC<{children:React.ReactNode}>=({children})=><svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position:'absolute',inset:0,overflow:'visible'}}>{children}</svg>;
const Defs:React.FC<{id:string}>=({id})=><defs>
 <radialGradient id={`${id}-orb`} cx="32%" cy="23%" r="78%"><stop offset="0" stopColor="#FFF0C9"/><stop offset=".35" stopColor="#FFBF7E"/><stop offset=".72" stopColor="#E48556"/><stop offset="1" stopColor="#6B3541"/></radialGradient>
 <radialGradient id={`${id}-halo`}><stop offset="0" stopColor={C.amber} stopOpacity=".3"/><stop offset="1" stopColor={C.amber} stopOpacity="0"/></radialGradient>
 <linearGradient id={`${id}-blue`} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#A8B6FF"/><stop offset=".55" stopColor={C.blue}/><stop offset="1" stopColor="#344566"/></linearGradient>
 <linearGradient id={`${id}-gold`} x1="0" x2="1"><stop stopColor="#FFC98C"/><stop offset="1" stopColor="#DB7950"/></linearGradient>
 <linearGradient id={`${id}-stone`} x1="0" y1="0" x2=".6" y2="1"><stop stopColor="#C9C9C7"/><stop offset="1" stopColor="#777E91"/></linearGradient>
</defs>;
const Orb:React.FC<{x:number,y:number,r?:number,id:string,halo?:boolean}>=({x,y,r=95,id,halo=true})=><g>{halo&&<circle cx={x} cy={y} r={r*2.8} fill={`url(#${id}-halo)`}/>}<ellipse cx={x+12} cy={y+r*1.2} rx={r*.72} ry={r*.12} fill="#000" opacity=".11"/><circle cx={x} cy={y} r={r} fill={`url(#${id}-orb)`}/><ellipse cx={x-r*.24} cy={y-r*.37} rx={r*.34} ry={r*.15} fill="#FFF5D8" opacity=".22" transform={`rotate(-30 ${x} ${y})`}/></g>;
const SmallLabel:React.FC<{children:React.ReactNode,y:number,x?:number,color?:string}>=({children,y,x=110,color=C.slate})=><Text x={x} y={y} size={24} weight={600} color={color} style={{letterSpacing:'.18em'}}>{children}</Text>;

function Question({t,id}:{t:number,id:string}){
 const a=smooth(t/7); const r=210+18*wob(t,.5);
 return <><Reveal t={t+.4} lines={['BÌNH','AN']} y={340} size={166}/><Text y={725} size={36} weight={400} color="#A9ADB6">Có thật sự đến dễ dàng?</Text>
 <SVG><Defs id={id}/><g transform={`translate(550 1060) rotate(${-12+t*2})`}>
 {[0,1,2,3].map(i=><ellipse key={i} cx="0" cy="0" rx={r+i*53} ry={75+i*22} transform={`rotate(${i*31})`} fill="none" stroke={i===0?C.amber:'#434B60'} strokeWidth={i===0?2:1} opacity={.65-i*.1}/>)}
 <circle cx="0" cy="0" r="340" fill="none" stroke="#343B4D" strokeDasharray="2 15"/>
 </g><Orb x={550+Math.sin(t*.5)*12} y={1035} r={116+5*wob(t,.7)} id={id}/>
 <path d="M110 1220 L280 1220" stroke={C.amber} strokeWidth="2"/><circle cx="280" cy="1220" r="4" fill={C.amber}/></SVG>
 <SmallLabel y={1260}>MỘT HÀNH TRÌNH TRƯỞNG THÀNH</SmallLabel></>;
}
function Ratio({t,id}:{t:number,id:string}){
 const phase=enter(t,3.15,.8); const pct=Math.round(lerp(1,99,phase));
 return <><SmallLabel y={300}>LỜI NHẮC → TRẢI NGHIỆM</SmallLabel>
 <Text y={360} size={250} color={C.amber} style={{letterSpacing:'-.085em'}}>{pct}<span style={{fontSize:110}}>%</span></Text>
 <Text y={660} size={65} weight={600}>{phase<.5?'là lời khuyên.':'là tự mình đi qua.'}</Text>
 <SVG><Defs id={id}/>{Array.from({length:100},(_,i)=>{const x=142+(i%10)*82; const y=850+Math.floor(i/10)*39; const p=enter(t,.25+i*.004,.6);const lit=i===0||i/100<phase;return <circle key={i} cx={x} cy={y+(1-p)*35} r={lit?10.5:5.5} fill={lit?C.amber:'#42485B'} opacity={p}/>})}<path d="M110 1274 H930" stroke="#495063"/><path d="M110 1274 H930" stroke={C.amber} strokeWidth="4" pathLength="1" strokeDasharray="1" strokeDashoffset={1-phase}/></SVG>
 <Text y={1310} size={29} weight={400} color="#A9ADB6">Có những điều, phải trải qua mới hiểu.</Text></>;
}
function Fracture({t,id}:{t:number,id:string}){
 const split=smooth((t-1.5)/2), heal=smooth((t-5.5)/3.5);
 const polygons=['M540 730 L365 795 L310 1030 L470 1150 L505 985 L475 870 Z','M540 730 L740 810 L800 1020 L635 1145 L575 1000 L610 895 Z','M470 1150 L505 985 L475 870 L540 730 L610 895 L575 1000 L635 1145 L540 1190 Z'];
 return <><Reveal t={t} lines={['ĐI QUA','ĐAU THƯƠNG.']} size={95} color={C.ink}/>
 <SVG><Defs id={id}/><circle cx="540" cy="960" r="315" fill="none" stroke="#D5CEC4"/>
 {polygons.map((d,i)=><path key={i} d={d} fill={`url(#${id}-stone)`} stroke={C.paper} strokeWidth="3" transform={`translate(${(i===0?-26:i===1?26:0)*split*(1-heal)} ${(i===2?30:0)*split*(1-heal)})`}/>)}
 <path d="M540 730 L475 870 L505 985 L470 1150 M475 870 L610 895 L575 1000 L635 1145" fill="none" stroke="#C88746" strokeWidth={7*heal} strokeLinecap="round" pathLength="1" strokeDasharray="1" strokeDashoffset={1-heal}/>
 {Array.from({length:9},(_,i)=><circle key={i} cx={240+i*73} cy={1210+Math.sin(i*2+t)*9} r={2} fill="#A2845B" opacity={heal*.7}/>)}
 </SVG><Text y={1270} size={36} color={C.ink} weight={600} style={{opacity:enter(t,5.5)}}>Vết nứt cũng là một khởi đầu.</Text></>;
}
function Icon({type}:{type:number}){
 if(type===0)return <g fill="none" stroke={C.amber} strokeWidth="5" strokeLinecap="round"><rect x="-42" y="-31" width="84" height="62" rx="11"/><path d="M10 -10 H48 V15 H10Z"/><circle cx="25" cy="2" r="2" fill={C.amber}/><path d="M-35 -31 V-42 H30"/></g>;
 if(type===1)return <g fill="none" stroke={C.blue} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><path d="M-42 -30 L-8 8 L15 -10 L44 32 M18 32 H44 V6"/></g>;
 return <g fill="none" stroke={C.amber} strokeWidth="4"><circle cx="-27" cy="-18" r="14"/><path d="M-48 29 Q-27 -4 -6 29"/><circle cx="34" cy="-18" r="14" opacity=".4"/><path d="M13 29 Q34 -4 55 29" opacity=".4"/><path d="M4 -44 V43" strokeDasharray="5 8" opacity=".4"/></g>;
}
function Teachers({t,id}:{t:number,id:string}){
 const labels=['VÍ RỖNG','THẤT BẠI','RỜI ĐI']; const tips=['dạy ta nỗ lực','dạy ta kiên cường','dạy ta buông bỏ'];
 return <><Reveal t={t} lines={['NHỮNG','NGƯỜI THẦY.']} size={101}/>
 <SVG><Defs id={id}/>{labels.map((s,i)=>{const p=enter(t,.5+i*1.35,.65);return <g key={s} opacity={p} transform={`translate(${(1-p)*100} 0)`}><rect x="110" y={680+i*207} width="820" height="175" rx="14" fill={i===1?'#222A3D':'#1B202C'} stroke="#343B4B"/><g transform={`translate(208 ${767+i*207})`}><Icon type={i}/></g><text x="302" y={752+i*207} fill={C.paper} fontSize="44" fontWeight="800">{s}</text><text x="304" y={800+i*207} fill="#ADB2BD" fontSize="28">{tips[i]}</text></g>})}</SVG>
 </>;
}
function Stairs({t,id}:{t:number,id:string}){
 const prog=smooth((t-.9)/7);const step=prog*5; const i=Math.floor(step),q=step-i;
 const x=195+step*115, y=1120-step*85-Math.sin(q*Math.PI)*80;
 return <><Reveal t={t} lines={['NGÃ XUỐNG.','ĐỨNG DẬY.']} size={100}/><Text y={600} size={48} color={C.amber} style={{opacity:enter(t,3)}}>Rồi bước tiếp.</Text>
 <SVG><Defs id={id}/>{Array.from({length:7},(_,j)=>{const px=120+j*115,py=1240-j*85;const p=enter(t,j*.1,.8);return <g key={j} opacity={p} transform={`translate(0 ${(1-p)*90})`}><path d={`M${px} ${py} l85 -45 115 34 -85 45Z`} fill={j<step?'#8797C8':'#424E6A'}/><path d={`M${px} ${py} l115 34 v125 l-115 -34Z`} fill="#29334C"/><path d={`M${px+115} ${py+34} l85 -45 v125 l-85 45Z`} fill="#1E273B"/><path d={`M${px} ${py} l85 -45 115 34`} fill="none" stroke="#B7C2E3" strokeWidth="1"/></g>})}<Orb x={x+30} y={y} r={46} id={id}/></SVG></>;
}
function Accept({t,id}:{t:number,id:string}){
 const p=smooth((t-4)/7);const xs=Array.from({length:150},(_,i)=>i/149);
 const path=xs.map((a,i)=>{const ang=a*Math.PI*6;const bx=540+240*Math.sin(ang),by=960+200*Math.sin(ang*1.33);const ex=170+a*740,ey=980+20*Math.sin(a*Math.PI*2);return `${i?'L':'M'}${lerp(bx,ex,p)} ${lerp(by,ey,p)}`}).join(' ');
 return <><Reveal t={t} lines={['CHẤP NHẬN.']} size={115} color={C.ink}/><Text y={500} size={42} color="#646A73" weight={400}>Để lòng thôi giằng co.</Text>
 <SVG><Defs id={id}/><path d={path} fill="none" stroke="#D9D4CB" strokeWidth="22" strokeLinecap="round" transform="translate(0 16)"/><path d={path} fill="none" stroke={`url(#${id}-gold)`} strokeWidth="18" strokeLinecap="round"/>
 <Orb x={lerp(540,875,p)} y={lerp(960,980,p)} r={52} id={id}/><circle cx="540" cy="980" r={310} fill="none" stroke="#CFC9C1" strokeDasharray="2 11" opacity={.7-p*.4}/>
 </SVG><Text y={1245} size={33} color={C.ink} weight={600} style={{opacity:enter(t,8)}}>Cuộc sống không cần hoàn hảo.</Text></>;
}
function Orbits({t,id}:{t:number,id:string}){
 return <><Reveal t={t} lines={['MỖI NGƯỜI,','MỘT LỐI RIÊNG.']} size={96} color={C.ink}/>
 <SVG><Defs id={id}/><g transform="translate(540 980)">
 {[0,1,2,3].map(i=>{const ang=t*(.1+i*.018)+i*1.4;const rx=170+i*47,ry=90+i*44;return <g key={i} transform={`rotate(${i*38-58})`}><ellipse rx={rx} ry={ry} fill="none" stroke={i%2===0?'#B1B8D0':'#CFC5B8'} strokeWidth="2"/><circle cx={rx*Math.cos(ang)} cy={ry*Math.sin(ang)} r={i===0?27:18} fill={i%2===0?C.blue:'#C99571'}/></g>})}
 <circle r="38" fill={C.ink}/><circle r="9" fill={C.paper}/></g></SVG>
 <Text y={1280} size={34} color={C.ink} weight={600}>Không ai phải giống một ai.</Text></>;
}
function Freedom({t,id}:{t:number,id:string}){
 const p=smooth((t-2)/5);return <><Reveal t={t} lines={['TỰ DO','LÀ CHÍNH MÌNH.']} size={98}/>
 <SVG><Defs id={id}/><g opacity={1-p}><rect x="305" y="710" width="470" height="500" rx="235" fill="none" stroke="#536078" strokeWidth="2"/>{[0,1,2,3,4].map(i=><path key={i} d={`M${375+i*82} 740 V1200`} stroke="#536078" strokeWidth="2"/>)}</g>
 {Array.from({length:9},(_,i)=>{const a=i*Math.PI*2/9;const r=lerp(45,290,p);return <g key={i} transform={`translate(${540+Math.cos(a+t*.06)*r} ${960+Math.sin(a+t*.06)*r*.85}) rotate(${i*40+t*3})`}><path d="M0 0 Q-65 -85 -110 -22 Q-75 19 0 0 Q65 -80 110 -22 Q75 19 0 0" fill={i%3===0?C.blue:C.amber} opacity={.45+.5*(i/9)}/></g>})}
 <Orb x={540} y={960} r={80+10*p} id={id}/><circle cx="540" cy="960" r={150+270*p} stroke="#4F5A73" fill="none" opacity={.5*(1-p)}/>
 </SVG><Text y={1300} size={34} weight={400} color="#ADB2BD">Thôi kiểm soát. Bắt đầu tôn trọng.</Text></>;
}
function Direction({t,id}:{t:number,id:string}){
 const ang=lerp(-120+Math.sin(t*3)*20,0,smooth((t-1)/4));
 return <><SmallLabel y={290}>HAI ĐIỀU ĐÁNG HƯỚNG TỚI</SmallLabel><Text y={335} size={68} color={C.blue}>01</Text><Reveal t={t} delay={.15} lines={['BIẾT MÌNH','ĐANG ĐI ĐÂU.']} y={455} size={92}/>
 <SVG><Defs id={id}/><g transform="translate(540 1050)"><circle r="265" fill="#182032"/><circle r="265" fill="none" stroke="#5A6683"/>{Array.from({length:60},(_,i)=>{const a=i*Math.PI/30;return <line key={i} x1={Math.cos(a)*245} y1={Math.sin(a)*245} x2={Math.cos(a)*(i%5===0?220:233)} y2={Math.sin(a)*(i%5===0?220:233)} stroke={i%5===0?C.paper:'#626E87'} strokeWidth={i%5===0?3:1}/>})}
 <g transform={`rotate(${ang})`}><path d="M0 -180 L58 75 L0 35Z" fill={C.amber}/><path d="M0 -180 L-58 75 L0 35Z" fill="#A46C58"/><path d="M0 155 L-30 59 L0 78 L30 59Z" fill={C.blue}/></g><circle r="14" fill={C.paper}/><path d="M0 -310 V-290 M-310 0 H-290 M310 0 H290 M0 310 V290" stroke={C.amber} strokeWidth="3"/></g></SVG></>;
}
function Stillness({t,id}:{t:number,id:string}){
 return <><SmallLabel y={290} color="#696F7B">HAI ĐIỀU ĐÁNG HƯỚNG TỚI</SmallLabel><Text y={335} size={68} color="#6175B5">02</Text><Reveal t={t} delay={.15} lines={['AN YÊN','VỚI HIỆN TẠI.']} y={455} size={92} color={C.ink}/>
 <SVG><Defs id={id}/>{[0,1,2,3,4].map(i=><ellipse key={i} cx="540" cy="1190" rx={110+i*69+Math.sin(t*.5-i)*7} ry={15+i*14} fill="none" stroke="#AEB4C4" strokeWidth="1" opacity={.55-i*.07}/>)}
 <ellipse cx="540" cy="1125" rx="175" ry="73" fill={`url(#${id}-stone)`}/><ellipse cx="540" cy="1032" rx="123" ry="47" fill={`url(#${id}-blue)`}/><Orb x={540} y={923-8*wob(t,.4)} r={67} id={id}/>
 </SVG><Text y={1310} size={32} color="#606874" weight={400}>Có hướng đi. Có sự thảnh thơi.</Text></>;
}
function Dawn({t,id,duration}:{t:number,id:string,duration:number}){
 const p=smooth(t/7);return <><SVG><Defs id={id}/><circle cx="540" cy={lerp(1180,1110,p)} r="260" fill={`url(#${id}-halo)`}/><circle cx="540" cy={lerp(1200,1110,p)} r="172" fill={`url(#${id}-orb)`}/><path d="M0 1155 Q270 1090 540 1155 T1080 1155 V1920 H0Z" fill="#172033"/>
 {Array.from({length:9},(_,i)=>{const y=1170+i*24;const w=lerp(15,130,p)*(1-i*.09);return <path key={i} d={`M${540-w} ${y} Q540 ${y+8*Math.sin(t*.4+i)} ${540+w} ${y}`} fill="none" stroke={C.amber} opacity={.38-i*.035} strokeWidth={3-i*.2}/>})}
 <path d="M0 1530 Q280 1360 600 1460 T1080 1410 V1920 H0" fill="#121927"/>
 </SVG><Reveal t={t} lines={['MỖI BƯỚC ĐI,','MỘT BÀI HỌC.']} y={335} size={92}/><Text y={640} size={36} weight={400} color="#ADB2BD" style={{opacity:enter(t,3)}}>Mỗi bước ngoặt, một lần lớn lên.</Text>
 <Text y={790} size={128} color={C.amber} align="center" style={{opacity:enter(t,Math.max(5,duration-5),1.1),transform:`translateY(${(1-enter(t,Math.max(5,duration-5),1.1))*30}px)`}}>BÌNH AN.</Text>
 </>;
}
function Captions({scene,t,light}:{scene:Scene,t:number,light:boolean}){
 const words=scene.words;const vt=t-.5;const pages:typeof words[]=[];let page:typeof words=[];
 for(const w of words){page.push(w);if(page.length>=4 || /[.?!,;:]$/.test(w.text)){pages.push(page);page=[]}}
 if(page.length)pages.push(page);
 const active=pages.find((p,i)=>vt>=p[0].start && vt<(pages[i+1]?.[0].start??p[p.length-1].end+.35));
 if(!active)return null;
 const p=enter(vt,active[0].start,.2);
 return <div data-caption style={{position:'absolute',left:125,top:1430,width:795,minHeight:124,display:'flex',alignItems:'flex-start',justifyContent:'center',gap:'0 .22em',flexWrap:'wrap',fontSize:48,fontWeight:600,lineHeight:1.35,letterSpacing:'-.025em',textAlign:'center',opacity:p,transform:`translateY(${(1-p)*9}px)`,color:light?C.ink:C.paper}}>{active.map((w,i)=><span key={i} style={{color:vt>=w.start&&vt<w.end?(light?'#9F542E':C.amber):undefined}}>{w.text}</span>)}</div>;
}
const LIGHT=new Set(['fracture','accept','orbits','stillness']);
export function SceneVisual({scene,index}:{scene:Scene,index:number}){
 const f=useCurrentFrame();const t=f/30; const light=LIGHT.has(scene.kind),id=`s${index}`;
 const incoming=index===0?1:out(f/20);const clip=index===0?'none':`circle(${incoming*1550}px at 540px 985px)`;
 const components:any={question:Question,ratio:Ratio,fracture:Fracture,teachers:Teachers,stairs:Stairs,accept:Accept,orbits:Orbits,freedom:Freedom,direction:Direction,stillness:Stillness,dawn:Dawn};const Art=components[scene.kind];
 return <AbsoluteFill style={{backgroundColor:light?C.paper:C.ink,clipPath:clip,fontFamily:'BeVietnam',overflow:'hidden'}}>
 <SVG><defs><radialGradient id={`${id}-bg`}><stop stopColor={light?'#FFFFFF':'#26334E'} stopOpacity={light?'.65':'.4'}/><stop offset="1" stopColor={light?C.paper:C.ink} stopOpacity="0"/></radialGradient></defs><ellipse cx={760+20*wob(t,.3)} cy="870" rx="740" ry="900" fill={`url(#${id}-bg)`}/>
 {Array.from({length:18},(_,j)=><circle key={j} cx={90+(j*157)%900} cy={260+(j*211)%1250+5*Math.sin(t*.3+j)} r={1.3} fill={light?'#9D9A93':'#7A849E'} opacity=".23"/>)}
 </SVG>
 <div style={{position:'absolute',left:110,top:224,display:'flex',width:820,justifyContent:'space-between',fontSize:21,letterSpacing:'.18em',fontWeight:600,color:light?'#69707A':'#A0A8B8'}}><span>BÌNH AN / MỘT HÀNH TRÌNH</span><span>{String(index+1).padStart(2,'0')}</span></div>
 <Art t={t} id={id} duration={scene.durationFrames/30}/>
 <Captions scene={scene} t={t} light={light}/>
 <div style={{position:'absolute',left:110,top:1665,width:820,borderTop:`1px solid ${light?'#CFCBC3':'#333B4D'}`,paddingTop:22,fontSize:20,fontWeight:400,color:light?'#6E747C':'#818DA4',letterSpacing:'.12em'}}>THỨC TỈNH · TRƯỞNG THÀNH · TỰ DO</div>
 </AbsoluteFill>;
}
export const Journey:React.FC<{title:string}>=()=>{
 const [fontHandle]=useState(()=>delayRender('Loading Vietnamese typography'));
 useEffect(()=>{Promise.all([400,600,800].map(w=>document.fonts.load(`${w} 100px BeVietnam`))).then(()=>continueRender(fontHandle)).catch(cancelRender)},[fontHandle]);
 return <AbsoluteFill style={{backgroundColor:C.ink}}>
 <style>{`@font-face{font-family:BeVietnam;src:url('${staticFile('BeVietnamPro-Regular.ttf')}');font-weight:400} @font-face{font-family:BeVietnam;src:url('${staticFile('BeVietnamPro-SemiBold.ttf')}');font-weight:600} @font-face{font-family:BeVietnam;src:url('${staticFile('BeVietnamPro-ExtraBold.ttf')}');font-weight:800} *{box-sizing:border-box}`}</style>
 {story.scenes.map((s,i)=><Sequence key={i} from={s.startFrame} durationInFrames={Math.min(s.durationFrames+20,story.durationInFrames-s.startFrame)}><SceneVisual scene={s} index={i}/></Sequence>)}
 <Audio src={staticFile('mix.wav')}/>
 </AbsoluteFill>;
};
