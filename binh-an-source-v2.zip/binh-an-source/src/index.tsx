import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {z} from 'zod';
import {Journey} from './Movie';
import story from '../public/story.json';
const schema=z.object({title:z.string()});
const Root=()=> <Composition id="Journey" component={Journey} fps={30} width={1080} height={1920} durationInFrames={story.durationInFrames} schema={schema} defaultProps={{title:'Bình an — một hành trình trở về'}}/>;
registerRoot(Root);
