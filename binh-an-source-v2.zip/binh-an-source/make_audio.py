from pathlib import Path
import ctypes as ct,ctypes.util,json,subprocess,math
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
root=Path(__file__).parent; pub=root/'public'; story=json.loads((pub/'story.json').read_text()); sr=44100; dur=story['durationInFrames']/30; N=round(dur*sr)
fs=ct.CDLL(ctypes.util.find_library('fluidsynth'))
def setup(name,ret,args):
 f=getattr(fs,name);f.restype=ret;f.argtypes=args;return f
ptr=ct.c_void_p; I=ct.c_int; F=ct.c_float; D=ct.c_double; S=ct.c_char_p
settings=setup('new_fluid_settings',ptr,[])();setup('fluid_settings_setnum',I,[ptr,S,D])(settings,b'synth.sample-rate',sr)
setup('fluid_settings_setnum',I,[ptr,S,D])(settings,b'synth.gain',.55)
synth=setup('new_fluid_synth',ptr,[ptr])(settings)
setup('fluid_synth_sfload',I,[ptr,S,I])(synth,b'/usr/share/sounds/sf2/TimGM6mb.sf2',1)
program=setup('fluid_synth_program_change',I,[ptr,I,I]);on=setup('fluid_synth_noteon',I,[ptr,I,I,I]);off=setup('fluid_synth_noteoff',I,[ptr,I,I])
write=setup('fluid_synth_write_float',I,[ptr,I,ptr,I,I,ptr,I,I])
for ch,p in [(0,0),(1,48),(2,89),(3,32)]: program(synth,ch,p)
for ch,vol in [(0,88),(1,42),(2,35),(3,45)]: setup('fluid_synth_cc',I,[ptr,I,I,I])(synth,ch,7,vol)
events=[]
def note(t,ch,key,vel,length):
 if t<dur-.4: events.extend([(round(t*sr),1,ch,key,vel),(min(N,round((t+length)*sr)),0,ch,key,0)])
beat=60/story['bpm']; bar=4*beat
chords=[[50,57,60,64,69],[46,53,57,62,65],[48,53,57,60,64],[48,55,59,62,67]]
for b in range(math.ceil(dur/bar)):
 t=b*bar; chord=chords[b%4]
 if t>dur-13: chord=[41,48,57,60,67]
 intensity= .45 if t<23 else .9 if t<65 else .55 if t<92 else .8 if t<110 else .35
 for k in chord[1:4]: note(t,1,k+12,int(31+15*intensity),bar*1.12)
 note(t,2,chord[0]+12,30,bar*1.3)
 note(t,3,chord[0]-12,45,bar*.7)
 pattern=[1,3,2,4,1,2,3,4] if intensity>.7 else [1,3,2,4]
 for j,ix in enumerate(pattern):
  tm=t+j*bar/len(pattern);key=chord[ix]+12+(12 if j%4==3 else 0)
  note(tm,0,key,round(42+intensity*20+(j%3)*3),2.2)
 # a high counter melody, sparse and cadential
 if b%4==3: note(t+2*beat,0,chord[4]+24,43,2.8)
events.sort(); music=np.zeros((N,2),np.float32);pos=0
for sample,kind,ch,key,vel in events+[(N,0,0,0,0)]:
 sample=min(sample,N)
 while pos<sample:
  block=min(4096,sample-pos);l=np.zeros(block,np.float32);r=np.zeros(block,np.float32)
  write(synth,block,l.ctypes.data,0,1,r.ctypes.data,0,1);music[pos:pos+block,0]=l;music[pos:pos+block,1]=r;pos+=block
 if kind:on(synth,ch,key,vel)
 else:off(synth,ch,key)
print('Score rendered',dur,flush=True)
# A very soft pulse enters with the difficult teachers and dissolves into acceptance.
rng=np.random.default_rng(42)
for b in range(math.ceil(dur/beat)):
 t=b*beat
 if not (23<t<66 or 95<t<108):continue
 if b%2:continue
 n=int(.26*sr);tt=np.arange(n)/sr
 kick=.027*np.sin(2*np.pi*(48*tt+35*.035*(1-np.exp(-tt/.035))))*np.exp(-tt*20)
 st=int(t*sr);en=min(N,st+n);music[st:en]+=kick[:en-st,None]
# Original transition design: airy short sweeps and a tuned glass-like accent.
sfx=np.zeros_like(music)
for i,s in enumerate(story['scenes']):
 t=s['startFrame']/30
 if i:
  length=.6; n=int(length*sr); tt=np.arange(n)/sr
  noise=rng.standard_normal(n); noise=sosfilt(butter(2,1500,fs=sr,btype='high',output='sos'),noise)
  sweep=noise*np.sin(np.pi*tt/length)**3*.013
  st=max(0,int((t-.22)*sr));en=min(N,st+n);pan=np.linspace(.8,.2,n)
  sfx[st:en,0]+=sweep[:en-st]*pan[:en-st];sfx[st:en,1]+=sweep[:en-st]*(1-pan[:en-st])
  n=int(1.7*sr);tt=np.arange(n)/sr;f=[440,523.25,587.33,659.25][i%4]
  bell=.015*(np.sin(2*np.pi*f*tt)+.23*np.sin(2*np.pi*f*2.01*tt))*np.exp(-tt*3.6)*(1-np.exp(-tt*80))
  st=int((t+.42)*sr);en=min(N,st+n);sfx[st:en]+=bell[:en-st,None]
voice=np.zeros(N,np.float32)
allpages=[]
for s in story['scenes']:
 data=subprocess.check_output(['ffmpeg','-v','error','-i',str(pub/s['audio']),'-f','f32le','-ac','1','-ar',str(sr),'-'])
 v=np.frombuffer(data,np.float32).copy();v*=.115/(np.sqrt(np.mean(v*v))+1e-9)
 start=(s['startFrame']+s['voiceOffsetFrames'])/30;st=round(start*sr);en=min(N,st+len(v));voice[st:en]+=v[:en-st]
 page=[]
 for w in s['words']:
  page.append(w)
  if len(page)>=4 or w['text'].endswith(('.',',','?','!')):
   allpages.append((start+page[0]['start'],start+page[-1]['end'],' '.join(w['text'] for w in page)));page=[]
 if page:allpages.append((start+page[0]['start'],start+page[-1]['end'],' '.join(w['text'] for w in page)))
# Soft ducking, preserving the musical spaces between phrases.
env=np.convolve(np.abs(voice)[::441],np.ones(20)/20,mode='same');env=np.interp(np.arange(N)/441,np.arange(len(env)),env)
duck=1-.48*np.clip(env/.07,0,1)
music*=.032/(np.sqrt(np.mean(music*music))+1e-9)
fade=np.minimum(np.arange(N)/(2*sr),1)*np.minimum((N-np.arange(N))/(3*sr),1)
music*=fade[:,None];mix=voice[:,None]+music*duck[:,None]+sfx
mix=np.tanh(mix*1.2)/1.2
wavfile.write(pub/'mix-raw.wav',sr,np.int16(np.clip(mix,-1,1)*32767))
wavfile.write(pub/'original-score.wav',sr,np.int16(np.clip(music,-1,1)*32767))
subprocess.run(['ffmpeg','-v','error','-y','-i',str(pub/'mix-raw.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=9','-ar',str(sr),str(pub/'mix.wav')],check=True)
def tc(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(root/'out/binh-an.vi.srt').write_text('\n\n'.join(f'{i+1}\n{tc(a)} --> {tc(b)}\n{text}' for i,(a,b,text) in enumerate(allpages))+'\n')
print('Mixed voice, original piano/strings score, transitions; captions exported.',flush=True)
