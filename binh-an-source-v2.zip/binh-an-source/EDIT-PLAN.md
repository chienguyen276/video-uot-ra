# Lịch dựng — Bình an

1080 × 1920 · 30 fps · 88 BPM · 11 cảnh · tổng 02:02.07

Một chấm sáng màu hổ phách là nhân vật xuyên suốt. Cảnh mới mở bằng cùng một khẩu độ tròn; màu nền và hình khối thay đổi theo ý nghĩa. Nhạc và hiệu ứng chuyển cảnh được kết xuất mới.

| Cảnh | Vào | Ra | Ý chính |
|---|---|---|---|
| 1 | 00:00.00 | 00:10.23 | BÌNH AN |
| 2 | 00:10.23 | 00:22.50 | 1% / 99% |
| 3 | 00:22.50 | 00:32.73 | ĐI QUA ĐAU THƯƠNG |
| 4 | 00:32.73 | 00:45.70 | BA NGƯỜI THẦY |
| 5 | 00:45.70 | 00:54.57 | ĐỨNG DẬY |
| 6 | 00:54.57 | 01:06.17 | CHẤP NHẬN |
| 7 | 01:06.17 | 01:16.40 | MỖI NGƯỜI MỘT LỐI |
| 8 | 01:16.40 | 01:27.30 | TỰ DO LÀ CHÍNH MÌNH |
| 9 | 01:27.30 | 01:37.53 | BIẾT MÌNH ĐI ĐÂU |
| 10 | 01:37.53 | 01:48.43 | AN YÊN Ở HIỆN TẠI |
| 11 | 01:48.43 | 02:02.07 | TRỞ VỀ VỚI CHÍNH MÌNH |

Lời đọc vào sau đầu cảnh 15 khung hình; mốc từng từ là dữ liệu WordBoundary từ chính giọng đọc đã phát. Hiệu ứng lướt chuyển cảnh dẫn trước hình 0.22 giây; tiếng điểm ngân nằm sau mốc vào cảnh 0.42 giây. Chuyển hình kéo dài 20 khung hình.

Nhạc nền piano/dây dùng các câu 4 phách, tăng cường ở phần thử thách và giảm ở phần tự do/an yên. Không thay đổi tốc độ lời đọc để ép theo nhạc.
