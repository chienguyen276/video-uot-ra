# BÌNH AN — một hành trình trở về

## Creative intent
An original Vietnamese motion film about peace earned through experience, acceptance and freedom. No frames, photographs, footage, logos or watermarks from the source. Its message is the sole source material. Newly composed score and a new Vietnamese voiceover.

## Style Prompt
Sculptural editorial motion design: a warm luminous orb travels through abstract spaces. Museum-poster typography meets precision vector architecture, tactile paper-white interludes, luminous amber against midnight ink. Rich scale changes, match morphs and rhythmic typography express the ideas rather than illustrate them literally. Intimate, purposeful, hopeful.

## Colors
- #11151E midnight ink: dark canvas
- #F3ECDD paper ivory: light canvas and primary type
- #FFB570 amber: hero orb and transformation
- #748BF0 periwinkle: supporting paths and contrast
- #899099 slate: low-priority notation

## Typography
Be Vietnam Pro, weights 400/600/700/800; Vietnamese diacritics must be preserved. Headlines 90–142px at 1080×1920, captions 46–52px. Display leading 1.04–1.14. Quiet labels 22px. Text remains within x=110..935, y=250..1510.

## Motion language
Premium personality, ease-out expo entrances and smooth ease-in-out transforms. Base unit 0.4s; grouped words 60ms apart. Main transitions use a shared circle aperture or spatial match morph, with a single primary transformation at a time. Holds after each meaningful reveal. Tempo 88 BPM, with deliberate 2/4/8-beat phrasing; narrative takes priority over rigid quantization. No retiming spoken words.

## Visual narrative
Orb -> narrowing rings -> 1/99 particle field -> fracture and gold repair -> three difficult teachers -> rising steps -> loose knot -> independent orbits -> direction + stillness -> dawn horizon.

## What NOT to Do
- No stock footage or source-video pixels.
- No decorative dashboard frames, progress meters or equal-size competing headlines.
- No fake word timestamps or unverified karaoke.
- No strobe transitions, gratuitous spins or uniformly frantic cutting.
- No generic call-to-action, subscription pitch or invented attribution.

## Current authorization
The latest user request replaces the earlier audio-preservation constraint: create a new film from the content, with new imagery, narration, music and transitions. Deliver to the previously authorized GitHub repository as a new version; preserve the earlier file.
