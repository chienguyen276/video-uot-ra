const {bundle}=require('@remotion/bundler');
const {renderStill,selectComposition,openBrowser}=require('@remotion/renderer');
const path=require('path');const story=require('./public/story.json');
(async()=>{
 const serveUrl=await bundle({entryPoint:path.resolve('src/index.tsx')});
 const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
 const composition=await selectComposition({serveUrl,id:'Journey',puppeteerInstance:browser});
 const frames=[0,...story.scenes.map(s=>s.startFrame+Math.min(130,Math.floor(s.durationFrames*.55))),story.scenes[5].startFrame+10,story.durationInFrames-1];
 for(let i=0;i<frames.length;i++){
  await renderStill({composition,serveUrl,output:`out/check-${String(i).padStart(2,'0')}.png`,frame:frames[i],puppeteerInstance:browser,logLevel:'error'});
  console.log(i,frames[i]);
 }
 await browser.close({silent:true});
})().catch(e=>{console.error(e);process.exit(1)});
