# Bình an — một hành trình trở về

Phim motion graphic dọc 1080 × 1920, 30 fps, thời lượng 2 phút 02 giây.

Lấy thông điệp từ video người dùng cung cấp và biên tập thành lời đọc mới. Toàn bộ hình ảnh là đồ họa vector được tạo bằng mã: không dùng cảnh quay, ảnh, watermark, hay âm thanh từ video cũ.

## Nội dung

11 cảnh đi từ khao khát bình an, trải nghiệm và những bài học khó khăn, đến chấp nhận, tự do, phương hướng và an yên trong hiện tại. Xem `SCRIPT.md` để đọc lời dẫn.

## Âm thanh và nguồn tài sản

- Lời đọc tiếng Việt mới: giọng tổng hợp vi-VN-NamMinhNeural.
- Nhạc nền: bản soạn riêng ở 88 BPM, piano, dây và nền mềm; âm sắc kết xuất bằng TimGM6mb SoundFont có sẵn trong môi trường. Không sử dụng bản nhạc thương mại hay âm thanh gốc.
- Chuyển cảnh: tiếng lướt và điểm ngân được tổng hợp riêng.
- Phông chữ: Be Vietnam Pro, SIL Open Font License; giấy phép trong `FONT-LICENSE.txt`.
- Hình ảnh: SVG và bố cục gốc trong `src/Movie.tsx`.
- Skill tham khảo: các gói iart-ai trong `skill-sources.json`; không cần các skill đó để kết xuất dự án này.

## Kết xuất lại

Cài Node.js và Chromium, chạy `npm ci`, rồi `npm run render`. Script mặc định dùng Chromium tại `/usr/bin/chromium`; thay đường dẫn nếu hệ thống khác. Âm thanh đã phối hoàn chỉnh đi kèm tại `public/mix.wav`, nên việc kết xuất lại không cần tài khoản hay dịch vụ giọng đọc.

`npm run studio` mở bản xem trước. `public/story.json` chứa lịch cảnh và mốc thời gian từ thực tế lời đọc; mọi chuyển động được tính theo số khung hình.

## Kiểm tra

Đã kiểm tra các khung hình đầu, giữa, cuối, 11 cảnh chính và các cảnh chuyển đổi; kiểm tra TypeScript; đo âm thanh khoảng -16 LUFS, đỉnh -1.5 dBTP trước mã hóa. Phụ đề `.srt` dùng cùng mốc lời đọc với chữ động trong phim.
