# Lịch dựng — AI và cách mình dùng

1080 × 1920 · 30 fps · 116 BPM · 14 cảnh · 01:26.37

| Cảnh | Vào | Ra | Ý chính |
|---|---|---|---|
| 1 | 00:00.00 | 00:05.70 | AI CÓ GIÚP LẬT KÈO? |
| 2 | 00:05.70 | 00:11.90 | MỘT CÂU HỎI TẠI CICON |
| 3 | 00:11.90 | 00:18.10 | ĐÚNG HƯỚNG. NHANH HƠN. |
| 4 | 00:18.10 | 00:24.30 | ĐÚNG. NHƯNG CHƯA ĐỦ. |
| 5 | 00:24.30 | 00:30.53 | ĐỪNG CHỈ TỐI ƯU QUÁ KHỨ |
| 6 | 00:30.53 | 00:37.23 | HÃY ĐỔI CÂU HỎI |
| 7 | 00:37.23 | 00:45.00 | GIAO VIỆC LẶP LẠI CHO AI |
| 8 | 00:45.00 | 00:52.77 | ĐỂ CON NGƯỜI LÀM ĐIỀU QUAN TRỌNG |
| 9 | 00:52.77 | 00:58.97 | AI SẼ THỰC SỰ LẮNG NGHE? |
| 10 | 00:58.97 | 01:07.23 | SỰ QUAN TÂM TẠO KHÁC BIỆT |
| 11 | 01:07.23 | 01:10.87 | KHÔNG DỪNG Ở TỐC ĐỘ |
| 12 | 01:10.87 | 01:15.00 | CÔNG NGHỆ ĐỂ HIỂU CON NGƯỜI |
| 13 | 01:15.00 | 01:20.70 | CÁCH BẠN DÙNG MỚI KHÁC BIỆT |
| 14 | 01:20.70 | 01:26.37 | BẠN SẼ DÙNG THỜI GIAN ẤY LÀM GÌ? |

Từng cảnh bắt đầu trên lưới 116 BPM; dùng mốc tích lũy để tránh lệch nhịp do làm tròn. Lời đọc vào sau 7 khung hình và không bị đổi tốc độ sau khi tạo. Mốc WordBoundary là thời gian thật của chính lời đọc trong video. Các chuyển ý trong cảnh bám từ khóa thật trong lời dẫn.

Cảnh lắng nghe giảm nhạc và bỏ trống/bass; các cảnh khác dùng nhịp điện tử, tiếng lướt nhẹ và điểm chạm. Nhạc tự giảm dưới lời nói.
