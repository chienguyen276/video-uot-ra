# AI — lợi thế nằm ở cách dùng

Video motion graphic dọc, biên tập từ bài viết người dùng cung cấp về AI và con người trong bối cảnh CICON 2026. Thời lượng 1 phút 26 giây, 1080 × 1920, 30 fps.

Thông điệp: AI giúp giải phóng thời gian khỏi công việc lặp lại; con người quyết định dùng thời gian đó để hiểu khách, cải thiện trải nghiệm và xây quan hệ.

## Phần hình và âm thanh

- 14 cảnh đồ họa vector/chữ động, nối bằng các lần quét hình theo nhịp và một đoạn chuyển nhẹ ở cảnh lắng nghe.
- Ảnh diễn giả do người dùng cung cấp được tách nền bằng công cụ tạo ảnh, bố cục lại thành ảnh tĩnh chuyển động nhẹ. Ảnh sân khấu thứ hai dùng tham khảo bối cảnh và màu sắc. Không dựng chuyển động nói hay giả lập giọng của người trong ảnh.
- Giọng đọc tiếng Việt mới: giọng tổng hợp `vi-VN-NamMinhNeural`, không phải bản thu phát biểu tại sự kiện.
- Nhạc nền được soạn riêng ở 116 BPM: Rhodes, pad, bass và trống; hiệu ứng chuyển cảnh được tổng hợp riêng. Nhạc giảm ở đoạn khách hàng mệt mỏi, rồi tăng trở lại khi chốt thông điệp.
- Phông Be Vietnam Pro theo SIL Open Font License, xem `FONT-LICENSE.txt`.
- Không thêm số liệu năng suất, doanh thu hay danh tính diễn giả không có trong nội dung gốc.

## Kết xuất lại

Cần Node.js và Chromium. Chạy `npm ci` rồi `npm run render`. Nếu Chromium ở đường dẫn khác `/usr/bin/chromium`, thay đường dẫn trong script. `npm run studio` mở bản xem trước.

Âm thanh đã phối tại `public/mix.wav`; ảnh, phông và mốc thời gian đi kèm, nên kết xuất lại không cần tài khoản dịch vụ giọng đọc. `SCRIPT.md` là lời dẫn đã biên tập; `public/story.json` chứa lịch cảnh và thời gian thật của từng từ.

Muốn tạo lại phần âm thanh từ đầu, `make_voice.py` dùng `edge-tts`, còn `make_audio.py` dùng NumPy, SciPy, FFmpeg và libfluidsynth với TimGM6mb SoundFont. Việc này không cần thiết để xuất lại video có sẵn.

## Kiểm tra

Đã kiểm tra TypeScript, khung hình mở/đóng, đủ 14 cảnh và các trạng thái chuyển ý chính, chữ tiếng Việt và các khoảng trống dành cho giao diện mạng xã hội. Âm thanh trước mã hóa khoảng -16.1 LUFS, đỉnh khoảng -2.9 dBTP. Phụ đề SRT và chữ động dùng cùng mốc thời gian của giọng đọc.
