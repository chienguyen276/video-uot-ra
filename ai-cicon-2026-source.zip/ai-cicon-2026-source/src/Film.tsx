import React,{CSSProperties,useEffect,useState} from 'react';
import {AbsoluteFill,Audio,Img,Sequence,staticFile,useCurrentFrame,delayRender,continueRender,cancelRender} from 'remotion';
import data from '../public/story.json';
const C={ink:'#090F20',paper:'#F3F5FA',blue:'#235CFF',cyan:'#9AE8EA',peach:'#FFC58C',gray:'#9BA8C3'};
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const out=(x:number)=>1-Math.pow(1-clamp(x),4);
const smooth=(x:number)=>{x=clamp(x);return x*x*(3-2*x)};
const lerp=(a:number,b:number,x:number)=>a+(b-a)*x;
const arrive=(t:number,d=0,dur=.4)=>out((t-d)/dur);
type S=typeof data.scenes[number];
const norm=(x:string)=>x.toLowerCase().replace(/[^\p{L}\p{N}]/gu,'');
function cue(s:S,phrase:string,fallback:number){const q=phrase.split(' ').map(norm);const at=s.words.findIndex((_,i)=>q.every((v,j)=>norm(s.words[i+j]?.text??'')===v));return at<0?fallback:s.words[at].start+s.voiceOffsetFrames/30}
const Txt:React.FC<{children:React.ReactNode,y:number,x?:number,size?:number,color?:string,weight?:number,width?:number,center?:boolean,style?:CSSProperties}>=({children,y,x=110,size=100,color=C.paper,weight=800,width=820,center=false,style={}})=><div data-type style={{position:'absolute',left:x,top:y,width,fontSize:size,color,fontWeight:weight,lineHeight:1.12,letterSpacing:'-.052em',textAlign:center?'center':'left',...style}}>{children}</div>;
const Lines:React.FC<{lines:string[],t:number,y?:number,size?:number,color?:string,delay?:number,center?:boolean}>=({lines,t,y=330,size=104,color=C.paper,delay=0,center=false})=><>{lines.map((l,i)=>{const p=arrive(t,delay+i*.055);return <Txt key={l+i} y={y+i*size*1.16} size={size} color={color} center={center} style={{opacity:p,transform:`translateY(${(1-p)*42}px)`,clipPath:`inset(${(1-p)*85}% 0 0 0)`}}>{l}</Txt>})}</>;
const Tag:React.FC<{children:React.ReactNode,y:number,color?:string,x?:number}>=({children,y,color=C.gray,x=110})=><Txt x={x} y={y} size={24} weight={600} color={color} style={{letterSpacing:'.14em'}}>{children}</Txt>;
const Svg:React.FC<{children:React.ReactNode}>=({children})=><svg width="1080" height="1920" viewBox="0 0 1080 1920" style={{position:'absolute',inset:0}}>{children}</svg>;
const Defs:React.FC<{id:string}>=({id})=><defs>
 <linearGradient id={`${id}-tile`} x1="0" y1="0" x2=".8" y2="1"><stop stopColor="#78A4FF"/><stop offset=".44" stopColor={C.blue}/><stop offset="1" stopColor="#153AA5"/></linearGradient>
 <linearGradient id={`${id}-human`} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#FFE1B6"/><stop offset="1" stopColor="#E89767"/></linearGradient>
 <radialGradient id={`${id}-glow`}><stop stopColor={C.blue} stopOpacity=".42"/><stop offset="1" stopColor={C.blue} stopOpacity="0"/></radialGradient>
 <linearGradient id={`${id}-line`}><stop stopColor={C.blue}/><stop offset="1" stopColor={C.peach}/></linearGradient>
</defs>;
function AiTile({id,x,y,size=235,rotate=0}:{id:string,x:number,y:number,size?:number,rotate?:number}){return <g transform={`translate(${x} ${y}) rotate(${rotate})`}><rect x={-size/2+13} y={-size/2+19} width={size} height={size} rx={size*.22} fill="#000" opacity=".2"/><rect x={-size/2} y={-size/2} width={size} height={size} rx={size*.22} fill={`url(#${id}-tile)`}/><path d={`M${-size*.3} ${-size*.4} H${size*.28} Q${size*.41} ${-size*.4} ${size*.41} ${-size*.28}`} fill="none" stroke="#D4E4FF" strokeOpacity=".5" strokeWidth="2"/><text x="-2" y={size*.18} textAnchor="middle" fontSize={size*.52} fontWeight="800" letterSpacing="-.09em" fill="white">AI</text></g>}
function Arrow({x,y,size=70,color=C.cyan,angle=0}:{x:number,y:number,size?:number,color?:string,angle?:number}){return <g transform={`translate(${x} ${y}) rotate(${angle})`} fill="none" stroke={color} strokeWidth={size*.105} strokeLinecap="square" strokeLinejoin="miter"><path d={`M${-size*.5} 0 H${size*.5} M0 ${-size*.5} L${size*.5} 0 L0 ${size*.5}`}/></g>}
function Clock({x,y,r=170,t=0,color=C.peach}:{x:number,y:number,r?:number,t?:number,color?:string}){return <g transform={`translate(${x} ${y})`}><circle r={r} fill="none" stroke={color} strokeWidth="5"/>{Array.from({length:12},(_,i)=><line key={i} x1={Math.cos(i*Math.PI/6)*(r-14)} y1={Math.sin(i*Math.PI/6)*(r-14)} x2={Math.cos(i*Math.PI/6)*(r-27)} y2={Math.sin(i*Math.PI/6)*(r-27)} stroke={color} strokeWidth="3"/>)}<path d={`M0 0 L0 ${-r*.6}`} stroke={color} strokeWidth="8" strokeLinecap="round" transform={`rotate(${t*70})`}/><path d={`M0 0 L${r*.43} 0`} stroke={color} strokeWidth="9" strokeLinecap="round"/><circle r="9" fill={color}/></g>}
function HumanIcon({x,y,r=50,color=C.peach}:{x:number,y:number,r?:number,color?:string}){return <g transform={`translate(${x} ${y})`} fill={color}><circle cy={-r*.55} r={r*.42}/><path d={`M${-r} ${r*.95} Q${-r*.9} ${r*.05} 0 ${r*.02} Q${r*.9} ${r*.05} ${r} ${r*.95}Z`}/></g>}
function Check({x,y,color=C.blue}:{x:number,y:number,color?:string}){return <path d={`M${x-13} ${y} l10 10 21 -25`} fill="none" stroke={color} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>}
function Hook({t,id}:{t:number,id:string}){
 const beat=Math.max(0,Math.sin(t*Math.PI*116/60));const p=arrive(t,.1,.5);
 return <><Txt y={260} size={33} weight={600}>DOANH NGHIỆP NHỎ</Txt><Lines t={t+.5} lines={['AI CÓ GIÚP','LẬT KÈO?']} y={348} size={130}/>
 <Svg><Defs id={id}/><circle cx="620" cy="1040" r="480" fill={`url(#${id}-glow)`}/><g transform={`translate(0 ${15*Math.sin(t*.9)})`}><path d="M160 1195 H350 V1045 H545 V895 H745" fill="none" stroke="#224295" strokeWidth="98" strokeLinejoin="round"/><path d="M160 1195 H350 V1045 H545 V895 H745" fill="none" stroke={C.cyan} strokeWidth="3" strokeLinejoin="round" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/><AiTile id={id} x={560} y={1040} size={300} rotate={-10+2*beat}/><Arrow x={800} y={870} size={100} angle={-90}/></g>
 <path d="M110 1275 H930" stroke="#314572" strokeWidth="2"/></Svg>
 <Txt y={1310} size={36} weight={600} color={C.cyan}>Câu trả lời có thể khác bạn nghĩ.</Txt></>;
}
function Context({t,id}:{t:number,id:string}){const p=arrive(t,.1,.6);return <>
 <Svg><Defs id={id}/><path d="M0 670 L1080 450 V1320 L0 1480Z" fill={C.blue}/><path d="M-50 1040 L1130 790 M-50 1120 L1130 870 M-50 1200 L1130 950" fill="none" stroke="#4878FF" strokeWidth="1"/></Svg>
 <Tag y={270}>TỪ MỘT CÂU HỎI TẠI</Tag><Lines t={t} lines={['CICON','VIETNAM 2026']} y={335} size={100}/>
 <Img src={staticFile('speaker-cutout.png')} style={{position:'absolute',left:25,top:655,width:1030,height:687,objectFit:'contain',opacity:p,transform:`translateY(${(1-p)*70}px) scale(${1+t*.003})`}}/>
 <Txt y={1350} size={27} color={C.cyan} weight={600}>Một góc nhìn về AI và con người.</Txt></>}
function Opportunity({t,id}:{t:number,id:string}){const p=smooth(t/3.2);return <>
 <Lines t={t} lines={['KHÔNG PHẢI','PHÉP MÀU.']} size={107}/><Txt y={610} size={50} weight={600} color={C.cyan}>Là cơ hội đi đúng hướng.</Txt>
 <Svg><Defs id={id}/><path d="M140 1110 H360 Q450 1110 450 1020 V920 Q450 825 550 825 H870" stroke="#23304D" fill="none" strokeWidth="52" strokeLinecap="round"/>
 <path d="M140 1110 H360 Q450 1110 450 1020 V920 Q450 825 550 825 H870" pathLength="1" stroke={C.blue} fill="none" strokeWidth="11" strokeDasharray="1" strokeDashoffset={1-p}/>
 <Arrow x={865} y={825} size={50} color={C.blue}/><path d="M140 1200 H880" stroke="#53617A" strokeDasharray="5 17" strokeWidth="2"/>
 <AiTile id={id} x={lerp(210,760,p)} y={lerp(1090,825,p)} size={150}/>
 <text x="140" y="1265" fill={C.gray} fontSize="27">CƠ HỘI</text><text x="710" y="1265" fill={C.cyan} fontSize="27">HƯỚNG ĐI</text></Svg></>}
function Cost({t,id,s}:{t:number,id:string,s:S}){const hit=cue(s,'Đúng',2.4),p=arrive(t,hit,.4);return <>
 <Tag y={290} color="#61728D">NHIỀU NGƯỜI CHỈ NHÌN THẤY</Tag><Lines t={t} lines={['CẮT CHI PHÍ.','GIẢM NHÂN SỰ.']} y={365} size={96} color={C.ink}/>
 <Svg><Defs id={id}/>{[0,1].map(i=><g key={i} transform={`translate(${140+i*425} 810)`}><rect width="365" height="330" rx="25" fill={i?C.ink:'#E2E8F6'}/><text x="40" y="86" fontSize="31" fontWeight="600" fill={i?C.paper:'#5C6B86'}>{i?'NHÂN SỰ':'CHI PHÍ'}</text><path d="M55 160 L140 225 L210 180 L290 245" fill="none" stroke={i?C.cyan:C.blue} strokeWidth="15"/><Arrow x={276} y={233} size={40} color={i?C.cyan:C.blue} angle={45}/></g>)}
 <path d="M100 1190 L955 780" stroke={C.blue} strokeWidth="8" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/></Svg>
 <Txt y={1225} size={76} color={C.blue} style={{opacity:p,transform:`translateY(${(1-p)*40}px)`}}>ĐÚNG. CHƯA ĐỦ.</Txt></>}
function Past({t,id,s}:{t:number,id:string,s:S}){const hit=cue(s,'Tương lai',2.8),future=t>hit,p=arrive(t,hit,.6);return <>
 <Lines t={future?t-hit:t} lines={future?['TƯƠNG LAI','CẦN CÁCH DÙNG','KHÁC.']:['NHANH HƠN','VIỆC CŨ?']} size={future?91:110} color={C.ink}/>
 <Svg><Defs id={id}/><g opacity={1-p}><rect x="155" y="900" width="755" height="230" rx="115" fill="none" stroke="#CCD6EC" strokeWidth="40"/>
 {Array.from({length:5},(_,i)=>{const q=(i/5+t*.18)%1;let x=175+q*700;return <g key={i} transform={`translate(${x} 1015)`}><rect x="-60" y="-85" width="120" height="170" rx="9" fill={C.paper} stroke={C.blue} strokeWidth="3"/><path d="M-35 -35 H30 M-35 -5 H30 M-35 25 H10" stroke={C.blue} strokeWidth="5"/></g>})}</g>
 <g opacity={p}><path d="M150 1170 L340 1040 L520 1080 L890 830" fill="none" stroke="#CFD9F1" strokeWidth="60" strokeLinejoin="round"/><path d="M150 1170 L340 1040 L520 1080 L890 830" fill="none" stroke={C.blue} strokeWidth="8" strokeLinejoin="round" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/><Arrow x={870} y={845} size={60} angle={-34} color={C.blue}/></g></Svg>
 <Txt y={1290} size={38} color={future?C.blue:'#66738B'} weight={600}>{future?'Tạo giá trị mới.':'Hay chỉ tối ưu quá khứ?'}</Txt></>}
function Question({t,id,s}:{t:number,id:string,s:S}){const hit=cue(s,'Hãy hỏi',2.3),phase=t>=hit;return <>
 <Tag y={280}>ĐẾN LÚC ĐỔI CÂU HỎI</Tag><Lines t={phase?t-hit:t} lines={phase?['GIẢI PHÓNG','THỜI GIAN','CHO ĐIỀU GÌ?']:['AI THAY','ĐƯỢC AI?']} size={phase?101:130} color={phase?C.cyan:C.paper}/>
 <Svg><Defs id={id}/><g opacity={1-arrive(t,hit,.4)}><AiTile id={id} x={540} y={1030} size={270}/><path d="M290 900 L800 1150" stroke={C.peach} strokeWidth="9"/></g>
 <g opacity={arrive(t,hit,.4)}><Clock x={540} y={1095} r={178} t={(t-hit)*.35} color={C.cyan}/>{[0,1,2].map(i=><path key={i} d={`M${230+i*36} 1010 l-45 85 45 85`} fill="none" stroke={C.blue} strokeWidth="5"/>)}{[0,1,2].map(i=><path key={i} d={`M${850-i*36} 1010 l45 85 -45 85`} fill="none" stroke={C.blue} strokeWidth="5"/>)}</g></Svg></>}
function Routine({t,id,s}:{t:number,id:string,s:S}){
 const acts=[.35,cue(s,'Báo một',2.3),cue(s,'Để AI',4.1)];const labels=['HỢP ĐỒNG SẮP HẾT HẠN','PHÒNG CẦN SỬA','CÔNG VIỆC LẶP LẠI'];
 return <><Lines t={t} lines={['GIAO VIỆC','LẶP LẠI CHO AI.']} size={97}/>
 <Svg><Defs id={id}/>{labels.map((txt,i)=>{const p=arrive(t,acts[i],.4);return <g key={i} opacity={p} transform={`translate(${(1-p)*130} 0)`}><rect x="110" y={715+i*165} width="820" height="136" rx="20" fill="#151F39" stroke="#30436B"/><rect x="140" y={745+i*165} width="68" height="68" rx="16" fill={C.blue}/><Check x={173} y={782+i*165} color="white"/><text x="238" y={795+i*165} fill={C.paper} fontSize="31" fontWeight="600">{txt}</text><circle cx="878" cy={783+i*165} r="6" fill={C.cyan}/></g>})}
 <path d="M540 1215 V1280" fill="none" stroke={C.cyan} strokeWidth="3"/><AiTile id={id} x={540} y={1280} size={97}/></Svg></>}
function Priorities({t,id,s}:{t:number,id:string,s:S}){
 const acts=[.1,cue(s,'Tạo trải nghiệm',2.4),cue(s,'Và xây',4.1)];const titles=['HIỂU SÂU.','TRẢI NGHIỆM.','GẮN KẾT.'];const subs=['Khách hàng thực sự cần gì?','Làm tốt hơn điều quan trọng.','Một mối quan hệ bền hơn.'];
 return <><Tag y={280} color="#5E708E">ĐỂ CON NGƯỜI DÀNH THỜI GIAN CHO</Tag>
 {titles.map((title,i)=>{const p=arrive(t,acts[i],.45);return <React.Fragment key={i}><Txt y={390+i*286} size={i===1?91:116} color={C.ink} style={{opacity:p,transform:`translateX(${(1-p)*-45}px)`}}>{title}</Txt><Txt y={540+i*286} size={32} color="#596985" weight={400} style={{opacity:p}}>{subs[i]}</Txt></React.Fragment>})}
 <Svg><Defs id={id}/><path d="M110 1260 H930" stroke="#C6D2E9" strokeWidth="2"/>{[0,1,2].map(i=><circle key={i} cx={175+i*325} cy="1260" r="11" fill={t>=acts[i]?C.blue:'#C6D2E9'}/> )}</Svg></>}
function Conversation({t,id}:{t:number,id:string}){const p=smooth((t-1)/2);return <>
 <Lines t={t} lines={['NHƯNG KHI','KHÁCH MỆT MỎI…']} size={96} color={C.ink}/>
 <Svg><Defs id={id}/><ellipse cx="540" cy="1240" rx="390" ry="30" fill="#DFE3EA"/>
 {/* tired customer, seated, leaning inward */}
 <path d="M190 1020 H440 V1250 H190Z" fill="#D8DFEC"/><path d="M240 1180 V1270 M400 1180 V1270" stroke="#7B8AA4" strokeWidth="12"/>
 <path d="M248 1070 Q245 940 350 930 Q425 950 440 1090 L420 1170 H270Z" fill="#7385AF"/>
 <path d="M332 860 Q300 888 320 934 L350 963 L392 915 L390 863Z" fill={C.peach}/><path d="M316 880 Q300 812 350 815 Q407 810 401 882 L377 864 L335 882Z" fill={C.ink}/>
 <path d="M350 1070 L396 1002 L378 920" fill="none" stroke={C.peach} strokeWidth="27" strokeLinecap="round"/>
 <path d="M300 1170 L310 1270 M392 1170 L430 1270" fill="none" stroke={C.ink} strokeWidth="43" strokeLinecap="round"/>
 {/* listener, present and leaning towards customer */}
 <path d="M680 1020 H895 V1250 H680Z" fill="#D8DFEC"/><path d="M711 1065 Q690 955 771 936 Q865 944 865 1092 L845 1170 H713Z" fill={C.blue}/>
 <ellipse cx="760" cy="892" rx="43" ry="52" fill={C.peach}/><path d="M720 892 Q705 823 760 829 Q818 829 804 899 L781 867 L730 879Z" fill={C.ink}/>
 <path d="M740 1043 L669 1100 L615 1081" fill="none" stroke={C.peach} strokeWidth="25" strokeLinecap="round"/>
 <path d="M748 1170 L715 1270 M815 1170 L820 1270" fill="none" stroke={C.ink} strokeWidth="43" strokeLinecap="round"/>
 <g opacity={p} transform={`translate(0 ${(1-p)*25})`}><rect x="420" y="720" width="280" height="115" rx="30" fill="white"/><path d="M470 829 L455 865 L510 831" fill="white"/><text x="560" y="790" textAnchor="middle" fill={C.ink} fontSize="32" fontWeight="600">Tôi đang nghe.</text></g>
 </Svg><Txt y={1320} size={35} color={C.blue} weight={600}>Ai sẽ ngồi xuống và lắng nghe?</Txt></>}
function Care({t,id,s}:{t:number,id:string,s:S}){const hit=cue(s,'Một cách',1.7),second=t>hit;return <>
 <Lines t={second?t-hit:t} lines={second?['GIẢI QUYẾT','THẤU TÌNH.']:['HỎI HAN','ĐÚNG LÚC.']} size={112} color={C.ink}/>
 <Svg><Defs id={id}/><path d="M250 1035 Q540 780 820 1035" stroke="#D4DEEF" fill="none" strokeWidth="3"/>
 <rect x="155" y="820" width="390" height="225" rx="47" fill={C.blue}/><path d="M230 1038 L213 1095 L290 1038Z" fill={C.blue}/><path d="M225 890 H472 M225 938 H400" stroke={C.paper} strokeWidth="12" strokeLinecap="round"/>
 <g transform={`translate(0 ${-10*Math.sin(t)})`}><rect x="540" y="1010" width="370" height="210" rx="45" fill={C.peach}/><path d="M805 1200 L840 1260 L770 1210" fill={C.peach}/><path d="M722 1144 C673 1118 676 1076 704 1076 Q721 1076 731 1094 Q749 1070 770 1080 C800 1101 765 1135 731 1157Z" fill="#AE674A"/></g>
 </Svg><Txt y={1300} size={34} weight={600} color="#53647E">Quan tâm thật. Kết nối bền.</Txt></>}
function Speed({t,id}:{t:number,id:string}){const p=arrive(t,1.2,.3);return <>
 <Tag y={300}>LỢI THẾ KHÔNG DỪNG Ở</Tag><Lines t={t} lines={['NHANH','HƠN.']} y={405} size={170}/>
 <Svg><Defs id={id}/>{[0,1,2,3,4].map(i=><path key={i} d={`M${110+i*30} ${1030+i*47} H${630+i*43}`} fill="none" stroke={i%2?C.cyan:'#344C82'} strokeWidth={i===2?14:3} transform={`translate(${Math.sin(t*5+i)*18} 0)`}/>)}<Arrow x={815} y={1110} size={165} color={C.cyan}/>
 <path d="M102 575 L925 400" stroke={C.blue} strokeWidth={8*p} pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/></Svg>
 <Txt y={1300} size={44} color={C.cyan}>Vậy, điều gì mới tạo khác biệt?</Txt></>}
function Human({t,id}:{t:number,id:string}){const p=arrive(t,.7,1.1);return <>
 <Lines t={t} lines={['DÙNG CÔNG NGHỆ','ĐỂ HIỂU','CON NGƯỜI.']} size={90}/>
 <Svg><Defs id={id}/><path d="M300 1050 H760" stroke="#304572" strokeWidth="15"/><path d="M300 1050 H760" stroke={`url(#${id}-line)`} strokeWidth="15" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/>
 <AiTile id={id} x={280} y={1050} size={224}/><rect x="657" y="937" width="224" height="224" rx="49" fill={`url(#${id}-human)`}/><HumanIcon x={769} y={1045} r={64} color="#804C39"/>
 <circle cx="525" cy="1050" r="44" fill={C.ink}/><path d="M512 1050 L523 1060 L541 1037" fill="none" stroke={C.cyan} strokeWidth="6" strokeLinecap="round"/>
 <text x="280" y="1255" textAnchor="middle" fontSize="28" fill={C.cyan}>CÔNG NGHỆ</text><text x="769" y="1255" textAnchor="middle" fontSize="28" fill={C.peach}>THẤU HIỂU</text></Svg></>}
function Agency({t,id,s}:{t:number,id:string,s:S}){const hit=cue(s,'Cách bạn',2.4),change=t>=hit;return <>
 <Lines t={change?t-hit:t} lines={change?['CÁCH BẠN DÙNG','MỚI KHÁC BIỆT.']:['AI KHÔNG','THAY THẾ','CON NGƯỜI.']} size={change?93:102} color={C.ink}/>
 <Svg><Defs id={id}/><g transform={`translate(0 ${7*Math.sin(t)})`}><AiTile id={id} x={440} y={1025} size={255} rotate={-7}/><rect x="548" y="1050" width="270" height="115" rx="57" fill={C.ink}/><circle cx={change?750:605} cy="1107" r="43" fill={change?C.peach:C.paper}/><HumanIcon x={750} y={1106} r={26} color={change?'#804C39':'#A8B4CE'}/></g>
 <path d="M185 1270 H905" stroke="#CFDAEF" strokeWidth="2"/></Svg><Txt y={1300} size={36} color={C.blue} weight={600}>AI là công cụ. Con người chọn cách dùng.</Txt></>}
function Final({t,id,s}:{t:number,id:string,s:S}){const hit=cue(s,'để làm gì',3.7),p=arrive(t,Math.min(3.2,hit),.5);return <>
 <Tag y={275} color={C.ink}>THỜI GIAN ĐƯỢC GIẢI PHÓNG</Tag><Lines t={t} lines={['BẠN SẼ','DÙNG ĐỂ','LÀM GÌ?']} y={375} size={137} color={C.ink}/>
 <Svg><Defs id={id}/><g transform={`translate(0 ${20*(1-p)})`}><Clock x={540} y={1100} r={160} t={Math.min(t,3.6)*.7} color={C.ink}/><path d="M110 1340 H930" stroke={C.ink} strokeWidth="2"/><circle cx={110+820*smooth(t/5)} cy="1340" r="9" fill={C.ink}/></g></Svg>
 <Txt y={1585} size={24} weight={600} color="#795437" style={{letterSpacing:'.04em'}}>Biên tập từ nội dung chia sẻ tại CICON 2026.</Txt></>}
const LIGHT=new Set(['cost','past','priorities','listen','care','agency']);
const PAGES=new Map<S, S['words'][]>();
for(const s of data.scenes){const pages:S['words'][]=[];let p:S['words']=[];for(const w of s.words){p.push(w);if(p.length>=5||/[.?!,;:]$/.test(w.text)){pages.push(p);p=[]}}if(p.length)pages.push(p);PAGES.set(s,pages)}
function Captions({s,t,light,peach}:{s:S,t:number,light:boolean,peach:boolean}){const vt=t-s.voiceOffsetFrames/30;const pages=PAGES.get(s)!;const p=pages.find((p,i)=>vt>=p[0].start&&vt<(pages[i+1]?.[0].start??p[p.length-1].end+.15));if(!p)return null;return <div data-caption style={{position:'absolute',left:120,top:1450,width:810,display:'flex',justifyContent:'center',flexWrap:'wrap',gap:'0 .22em',fontSize:49,lineHeight:1.35,fontWeight:600,letterSpacing:'-.025em',color:light||peach?C.ink:C.paper,opacity:arrive(vt,p[0].start,.16)}}>{p.map((w,i)=><span key={i} style={{color:vt>=w.start&&vt<w.end?(light?C.blue:peach?'#8A4A24':C.cyan):undefined}}>{w.text}</span>)}</div>}
function Scene({s,index}:{s:S,index:number}){
 const f=useCurrentFrame(),t=f/30,id=`s${index}`,light=LIGHT.has(s.kind),peach=s.kind==='final';
 const comps:Record<string,React.ComponentType<any>>={hook:Hook,context:Context,opportunity:Opportunity,cost:Cost,past:Past,question:Question,routine:Routine,priorities:Priorities,listen:Conversation,care:Care,speed:Speed,human:Human,agency:Agency,final:Final};const Art=comps[s.kind];
 const transition=out(f/12);const clip=index===0||s.kind==='listen'?'none':index%2?`polygon(0 ${100-transition*130}%,100% ${130-transition*130}%,100% 100%,0 100%)`:`inset(0 ${(1-transition)*100}% 0 0)`;
 return <AbsoluteFill style={{backgroundColor:peach?C.peach:light?C.paper:C.ink,clipPath:clip,opacity:s.kind==='listen'?smooth(f/14):1,fontFamily:'BeVietnam',overflow:'hidden'}}>
 <Svg>{!light&&!peach&&<><path d="M1080 510 L550 1020 L1080 1550Z" fill="#0D1932"/>{Array.from({length:6},(_,i)=><path key={i} d={`M${760+i*58} 0 L${-180+i*58} 1920`} stroke="#233A64" strokeWidth="1" opacity=".28"/>)}</>}</Svg>
 {s.kind!=='context'&&s.kind!=='final'&&<Tag y={222} color={light?'#657694':'#8D9FBE'}>AI × CON NGƯỜI</Tag>}
 <Art t={t} id={id} s={s}/><Captions s={s} t={t} light={light} peach={peach}/>
 </AbsoluteFill>;
}
export const Film:React.FC<{label:string}>=({label})=>{
 const [handle]=useState(()=>delayRender('Loading Vietnamese fonts'));
 useEffect(()=>{Promise.all([400,600,800].map(w=>document.fonts.load(`${w} 100px BeVietnam`))).then(()=>continueRender(handle)).catch(cancelRender)},[handle]);
 return <AbsoluteFill aria-label={label} style={{backgroundColor:C.ink}}>
 <style>{`@font-face{font-family:BeVietnam;src:url('${staticFile('BeVietnamPro-Regular.ttf')}');font-weight:400}@font-face{font-family:BeVietnam;src:url('${staticFile('BeVietnamPro-SemiBold.ttf')}');font-weight:600}@font-face{font-family:BeVietnam;src:url('${staticFile('BeVietnamPro-ExtraBold.ttf')}');font-weight:800}*{box-sizing:border-box}`}</style>
 {data.scenes.map((s,i)=><Sequence key={s.kind} from={s.startFrame} durationInFrames={Math.min(s.durationFrames+14,data.durationInFrames-s.startFrame)}><Scene s={s} index={i}/></Sequence>)}
 <Audio src={staticFile('mix.wav')}/>
 </AbsoluteFill>;
};
