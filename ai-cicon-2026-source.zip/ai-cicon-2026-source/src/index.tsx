import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {z} from 'zod';
import {Film} from './Film';
import data from '../public/story.json';
const schema=z.object({label:z.string()});
const Root=()=> <Composition id="AIHuman" component={Film} fps={30} width={1080} height={1920} durationInFrames={data.durationInFrames} schema={schema} defaultProps={{label:'AI — lợi thế nằm ở cách dùng'}}/>;
registerRoot(Root);
