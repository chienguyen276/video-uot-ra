# AI — lợi thế nằm ở cách dùng

## Brief
A fast Vietnamese 9:16 editorial motion graphic for a business owner to show their boss, based on the user-supplied CICON 2026 article. Explain that efficiency alone is incomplete: AI releases time for understanding people. Energetic, clear, credible. Target 75–90 seconds, 1080×1920 at 30 fps.

## Visual identity
Electric-blue business editorial, oversized Vietnamese typography, precise isometric workflow diagrams, animated cards and original human-centered illustration. Alternate ink and warm paper scenes to reset attention. First-frame curiosity question; early sourced speaker-photo cutout; increasingly human and warm imagery as the message turns from efficiency to empathy.

## Colors
- #090F20 ink navy — dark canvas
- #F3F5FA cool paper — light canvas
- #235CFF electric blue — AI and automation
- #9AE8EA ice cyan — paths and active technical details
- #FFC58C peach — humans, attention and time returned

## Typography
Be Vietnam Pro, 800 display and 600 body, with real Vietnamese glyphs. Display 88–160px; captions 48–52px. Text safe area x=110..935, y=240..1535. Fine labels 22px, readable on-screen headers. No decorative subtitle footer repeated in every shot.

## Motion language
Energetic editorial with no cartoon bounce. Base unit 0.2s; headline masks 0.4s, support entrances 0.2s, word stagger 50–60ms; ease-out-expo for arrival and smooth ease-in-out for spatial morphs. Fast, motivated diagonal panel wipes and match cuts alternate; a 0.3s dissolve and drum dropout make the empathy beat breathe. Visual changes every 2–4s within longer narration scenes, with one hero action at a time. Music at 116 BPM, pulse and bass for the first half; warm keys and lighter percussion during listening; confident rise into the final question.

## Story
Hook → CICON context → opportunity not magic → cost cuts are incomplete → past vs future → question reframed → routine tasks delegated → three human priorities → customer listening → service detail → speed reframed → technology for human understanding → human agency → final question.

## Assets and authenticity
User-provided seated speaker photo edited into a transparent cutout via image generation, used only as an illustrative still with slow parallax, never animated speech. No invented speaker name, company, factual event signage, or claimed original event audio. Newly generated Vietnamese narration, clearly described as such in delivery notes; no voice cloning. All other visuals are original SVG/typographic motion. Original music and synthesized transition sound effects.

## Avoid
No fake productivity statistics, customer names or business outcomes. No stock sci-fi robots. No endless neon HUD noise. No subtitle walls. No strobe flashes. No suggestion the synthetic narration is the speaker's actual recording.
