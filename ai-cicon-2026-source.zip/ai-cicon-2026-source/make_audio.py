from pathlib import Path
import ctypes as ct,ctypes.util,json,subprocess,math
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
r=Path(__file__).parent;p=r/'public';s=json.loads((p/'story.json').read_text());sr=44100;duration=s['durationInFrames']/30;N=round(duration*sr);beat=60/s['bpm'];bar=beat*4
rng=np.random.default_rng(2026)
starts={x['kind']:x['startFrame']/30 for x in s['scenes']};listen=starts['listen'];care=starts['care'];final=starts['final']
# Rhodes and airy sustained chords, rendered from the installed General MIDI soundfont.
fs=ct.CDLL(ctypes.util.find_library('fluidsynth'))
def api(name,restype,args):
 f=getattr(fs,name);f.restype=restype;f.argtypes=args;return f
P=ct.c_void_p;I=ct.c_int;D=ct.c_double;S=ct.c_char_p
settings=api('new_fluid_settings',P,[])();api('fluid_settings_setnum',I,[P,S,D])(settings,b'synth.sample-rate',sr);api('fluid_settings_setnum',I,[P,S,D])(settings,b'synth.gain',.5)
sy=api('new_fluid_synth',P,[P])(settings);api('fluid_synth_sfload',I,[P,S,I])(sy,b'/usr/share/sounds/sf2/TimGM6mb.sf2',1)
program=api('fluid_synth_program_change',I,[P,I,I]);program(sy,0,4);program(sy,1,89)
cc=api('fluid_synth_cc',I,[P,I,I,I]);cc(sy,0,7,87);cc(sy,1,7,39);cc(sy,0,10,48);cc(sy,1,10,75)
on=api('fluid_synth_noteon',I,[P,I,I,I]);off=api('fluid_synth_noteoff',I,[P,I,I]);write=api('fluid_synth_write_float',I,[P,I,P,I,I,P,I,I])
chords=[[52,55,59,62],[48,55,59,64],[43,54,59,62],[50,57,62,66]];events=[]
def note(t,ch,key,velocity,length):
 if t<duration-.6:events.extend([(round(t*sr),1,ch,key,velocity),(min(N,round((t+length)*sr)),0,ch,key,0)])
for b in range(math.ceil(duration/bar)):
 t=b*bar; chord=chords[b%4]
 for k in chord:note(t,1,k+12,38,bar*1.2)
 for j,k in enumerate(chord[1:]):note(t+j*.025,0,k+12,50 if t<listen or t>=care else 66,bar*.92)
 if b%2:note(t+2.5*beat,0,chord[-1]+12,58,1.5)
keys=np.zeros((N,2),np.float32);pos=0
for sample,kind,ch,key,v in sorted(events)+[(N,0,0,0,0)]:
 sample=min(sample,N)
 while pos<sample:
  n=min(4096,sample-pos);l=np.zeros(n,np.float32);rr=np.zeros(n,np.float32);write(sy,n,l.ctypes.data,0,1,rr.ctypes.data,0,1);keys[pos:pos+n]=np.stack([l,rr],axis=1);pos+=n
 if kind:on(sy,ch,key,v)
 else:off(sy,ch,key)
def add(dst,t,signal,amp=1,pan=.5):
 st=max(0,round(t*sr));en=min(N,st+len(signal))
 if en<=st:return
 x=np.asarray(signal[:en-st])*amp
 if x.ndim==1:dst[st:en,0]+=x*math.sqrt(1-pan);dst[st:en,1]+=x*math.sqrt(pan)
 else:dst[st:en]+=x
rhythm=np.zeros_like(keys);lead=np.zeros_like(keys);fx=np.zeros_like(keys)
def kick():
 tt=np.arange(int(.38*sr))/sr;phase=2*np.pi*(45*tt+70*.025*(1-np.exp(-tt/.025)));return np.sin(phase)*np.exp(-tt*13)*(1-np.exp(-tt*450))+.1*rng.normal(size=len(tt))*np.exp(-tt*150)
def snare():
 tt=np.arange(int(.19*sr))/sr;noise=sosfilt(butter(2,1400,fs=sr,btype='high',output='sos'),rng.normal(size=len(tt)));return noise*np.exp(-tt*32)+.35*np.sin(2*np.pi*180*tt)*np.exp(-tt*28)
def hat():
 tt=np.arange(int(.07*sr))/sr;noise=sosfilt(butter(2,6500,fs=sr,btype='high',output='sos'),rng.normal(size=len(tt)));return noise*np.exp(-tt*65)
def bass(key):
 tt=np.arange(int(.34*sr))/sr;f=440*2**((key-69)/12);return np.tanh(1.5*(np.sin(2*np.pi*f*tt)+.28*np.sin(2*np.pi*f*2*tt)))*np.exp(-tt*7)*(1-np.exp(-tt*90))
def pluck(key):
 tt=np.arange(int(1.1*sr))/sr;f=440*2**((key-69)/12);return (np.sin(2*np.pi*f*tt)*np.exp(-tt*4.2)+.26*np.sin(2*np.pi*f*2*tt)*np.exp(-tt*8)+.08*np.sin(2*np.pi*f*3*tt)*np.exp(-tt*12))*(1-np.exp(-tt*200))
for b in range(math.ceil(duration/beat)):
 t=b*beat;chord=chords[(b//4)%4];breakdown=listen-.01<=t<care;ending=t>final+1.2
 if not breakdown and not ending:
  power=.75 if care<=t<starts['speed'] else 1
  add(rhythm,t,kick(),.12*power)
  if b%4 in [1,3]:add(rhythm,t,snare(),.052*power,pan=.53)
  add(rhythm,t+.5*beat,hat(),.021*power,pan=.67)
  add(rhythm,t,hat(),.011*power,pan=.32)
  if b%2==0 or t>starts['routine']:add(rhythm,t+.03,bass(chord[0]-12),.12*power)
 # a restrained, repeating original motif; more air on the listening beat
 if (not breakdown and b%2==0) or (breakdown and b%4==0):
  melody=[0,2,1,3,2,1,3,1];key=chord[melody[(b//2)%8]]+24
  add(lead,t+.5*beat,pluck(key),.045 if not breakdown else .035,pan=.4)
  add(lead,t+.5*beat+.28,pluck(key),.012,pan=.78)
# Controlled transition air and tactile clicks; no big sweep over the listening beat.
for i,c in enumerate(s['scenes']):
 t=c['startFrame']/30
 if i and c['kind']!='listen':
  n=round(.32*sr);tt=np.arange(n)/sr;noise=sosfilt(butter(2,1700,fs=sr,btype='high',output='sos'),rng.normal(size=n));whoosh=noise*np.sin(np.pi*tt/.32)**2
  add(fx,t-.13,whoosh,.016,pan=.55)
 n=round(.17*sr);tt=np.arange(n)/sr;tap=np.sin(2*np.pi*(440+int(i%4)*110)*tt)*np.exp(-tt*34)*(1-np.exp(-tt*200));add(fx,t+.10,tap,.024,pan=.5)
# A single rising texture builds into the human-priorities section, then leaves space.
n=round(1.8*sr);tt=np.arange(n)/sr;air=sosfilt(butter(2,2500,fs=sr,btype='high',output='sos'),rng.normal(size=n))*np.sin(np.pi*tt/1.8)**2
add(fx,starts['priorities']-1.8,air,.009)
# Soft stereo reverb taps on keys and pluck sustain.
for delay,gain in [(.17,.09),(.31,.07),(.53,.04)]:
 d=round(delay*sr);keys[d:]+=keys[:-d,::-1]*gain
keys*=.035/(np.sqrt(np.mean(keys*keys))+1e-9)
music=keys+rhythm+lead
music*=.05/(np.sqrt(np.mean(music*music))+1e-9)
fade=np.minimum(np.arange(N)/(sr*.25),1)*np.minimum((N-np.arange(N))/(sr*1.8),1);music*=fade[:,None]
voice=np.zeros(N,np.float32);pages=[]
for c in s['scenes']:
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p/c['audio']),'-f','f32le','-ac','1','-ar',str(sr),'-']);v=np.frombuffer(raw,np.float32).copy();v*=.12/(np.sqrt(np.mean(v*v))+1e-9)
 start=(c['startFrame']+c['voiceOffsetFrames'])/30;st=round(start*sr);en=min(N,st+len(v));voice[st:en]+=v[:en-st]
 page=[]
 for w in c['words']:
  page.append(w)
  if len(page)>=5 or w['text'].endswith(('.',',','?','!',':')):
   pages.append((start+page[0]['start'],start+page[-1]['end'],' '.join(x['text'] for x in page)));page=[]
 if page:pages.append((start+page[0]['start'],start+page[-1]['end'],' '.join(x['text'] for x in page)))
env=np.convolve(np.abs(voice)[::441],np.ones(17)/17,mode='same');env=np.interp(np.arange(N)/441,np.arange(len(env)),env);duck=1-.54*np.clip(env/.065,0,1)
mix=voice[:,None]+music*duck[:,None]+fx
mix=np.tanh(mix*1.1)/1.1
wavfile.write(p/'mix-raw.wav',sr,np.int16(np.clip(mix,-1,1)*32767));wavfile.write(r/'work/original-music.wav',sr,np.int16(np.clip(music,-1,1)*32767))
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'mix-raw.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=8','-ar',str(sr),str(p/'mix.wav')],check=True)
def tc(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/ai-cach-minh-dung.vi.srt').write_text('\n\n'.join(f'{i+1}\n{tc(a)} --> {tc(b)}\n{text}' for i,(a,b,text) in enumerate(pages))+'\n')
print('Mixed',round(duration,2),'seconds: new voice, original 116-BPM score and timed transitions.',flush=True)
