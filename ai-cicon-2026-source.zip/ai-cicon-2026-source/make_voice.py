import asyncio,os,importlib,json,subprocess,math
from pathlib import Path
import edge_tts
m=importlib.import_module('edge_tts.communicate')
if os.environ.get('NODE_EXTRA_CA_CERTS'): m._SSL_CTX.load_verify_locations(cafile=os.environ['NODE_EXTRA_CA_CERTS'])
root=Path(__file__).parent;pub=root/'public';bpm=116;beat=60/bpm;fps=30
scenes=[
('hook','AI CÓ GIÚP LẬT KÈO?','AI có giúp doanh nghiệp nhỏ lật kèo? Câu trả lời có thể khác bạn nghĩ.'),
('context','MỘT CÂU HỎI TẠI CICON','Tại một buổi chia sẻ ở CICON, câu hỏi ấy mở ra một góc nhìn đáng suy ngẫm.'),
('opportunity','ĐÚNG HƯỚNG. NHANH HƠN.','AI không tự giúp bạn lật kèo. Nó giúp bạn đi đúng hướng, nhanh hơn.'),
('cost','ĐÚNG. NHƯNG CHƯA ĐỦ.','Cắt chi phí. Giảm nhân sự. Đúng, nhưng chưa đủ.'),
('past','ĐỪNG CHỈ TỐI ƯU QUÁ KHỨ','Làm nhanh hơn việc cũ chỉ là tối ưu quá khứ. Tương lai cần một cách dùng khác.'),
('question','HÃY ĐỔI CÂU HỎI','Đừng chỉ hỏi: AI thay được ai? Hãy hỏi: AI giải phóng thời gian cho điều gì?'),
('routine','GIAO VIỆC LẶP LẠI CHO AI','Nhắc hợp đồng sắp hết hạn. Báo một căn phòng cần sửa. Để AI xử lý những việc lặp lại.'),
('priorities','ĐỂ CON NGƯỜI LÀM ĐIỀU QUAN TRỌNG','Để con người hiểu khách sâu hơn. Tạo trải nghiệm tốt hơn. Và xây những mối quan hệ bền hơn.'),
('listen','AI SẼ THỰC SỰ LẮNG NGHE?','Nhưng khi một khách hàng đang mệt mỏi, ai sẽ ngồi xuống, lắng nghe, và hiểu điều họ thực sự cần?'),
('care','SỰ QUAN TÂM TẠO KHÁC BIỆT','Một lời hỏi han đúng lúc. Một cách giải quyết thấu tình. Những điều nhỏ ấy có thể khiến khách hàng muốn quay lại.'),
('speed','KHÔNG DỪNG Ở TỐC ĐỘ','Lợi thế không dừng ở ai làm nhanh hơn.'),
('human','CÔNG NGHỆ ĐỂ HIỂU CON NGƯỜI','Mà ở ai dùng công nghệ để hiểu con người tốt hơn.'),
('agency','CÁCH BẠN DÙNG MỚI KHÁC BIỆT','AI không thay thế con người. Cách bạn dùng AI mới tạo nên khác biệt.'),
('final','BẠN SẼ DÙNG THỜI GIAN ẤY LÀM GÌ?','Vậy, bạn sẽ dùng phần thời gian được giải phóng đó, để làm gì?')]
async def gen(i,s):
 p=pub/f'voice-{i:02d}.mp3';words=[]
 c=edge_tts.Communicate(s[2],voice='vi-VN-NamMinhNeural',rate='+12%',boundary='WordBoundary',proxy=os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy'))
 with p.open('wb') as f:
  async for chunk in c.stream():
   if chunk['type']=='audio':f.write(chunk['data'])
   elif chunk['type']=='WordBoundary':words.append({'text':chunk['text'],'start':chunk['offset']/1e7,'end':(chunk['offset']+chunk['duration'])/1e7})
 duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(p)],text=True))
 # Restore punctuation without changing provider timestamps.
 raw=s[2].split()
 if len(raw)==len(words):
  for w,txt in zip(words,raw):w['text']=txt
 return {'kind':s[0],'title':s[1],'text':s[2],'audio':p.name,'voiceDuration':duration,'words':words}
async def main():
 result=[];cursorBeat=0
 for i,s in enumerate(scenes):
  cache=pub/f'voice-{i:02d}.json'
  if cache.exists():r=json.loads(cache.read_text())
  else:
   for trial in range(6):
    try:r=await gen(i,s);cache.write_text(json.dumps(r,ensure_ascii=False));break
    except Exception as e:
     print('retry',i,trial,type(e).__name__,flush=True)
     if trial==5:raise
     await asyncio.sleep(1)
  r['startFrame']=round(cursorBeat*beat*fps);r['voiceOffsetFrames']=7
  nbeats=math.ceil((r['voiceDuration']+.52)/beat)
  if i==len(scenes)-1:nbeats+=2
  cursorBeat+=nbeats;r['durationFrames']=round(cursorBeat*beat*fps)-r['startFrame']
  result.append(r);print(i,r['kind'],r['voiceDuration'],r['durationFrames']/fps,flush=True)
 data={'fps':30,'width':1080,'height':1920,'bpm':bpm,'durationInFrames':round(cursorBeat*beat*fps),'scenes':result}
 (pub/'story.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
 (root/'SCRIPT.md').write_text('# AI — lợi thế nằm ở cách dùng\n\nLời dẫn biên tập từ nội dung người dùng cung cấp. Giọng đọc mới, không phải bản ghi lời nói của diễn giả tại sự kiện.\n\n'+'\n\n'.join(f'## {i+1}. {s[1]}\n\n{s[2]}' for i,s in enumerate(scenes)))
 print('TOTAL',data['durationInFrames']/fps,flush=True)
asyncio.run(main())
