from pathlib import Path
import json,re
p=Path('public/story.json');s=json.loads(p.read_text())
phrases={
'hook':['AI có giúp','doanh nghiệp nhỏ','lật kèo?','Câu trả lời','có thể khác bạn nghĩ.'],
'context':['Tại một buổi chia sẻ','ở CICON,','câu hỏi ấy mở ra','một góc nhìn','đáng suy ngẫm.'],
'opportunity':['AI không tự giúp bạn','lật kèo.','Nó giúp bạn','đi đúng hướng,','nhanh hơn.'],
'cost':['Cắt chi phí.','Giảm nhân sự.','Đúng,','nhưng chưa đủ.'],
'past':['Làm nhanh hơn việc cũ','chỉ là','tối ưu quá khứ.','Tương lai cần','một cách dùng khác.'],
'question':['Đừng chỉ hỏi:','AI thay được ai?','Hãy hỏi:','AI giải phóng thời gian','cho điều gì?'],
'routine':['Nhắc hợp đồng','sắp hết hạn.','Báo một căn phòng','cần sửa.','Để AI xử lý','những việc lặp lại.'],
'priorities':['Để con người','hiểu khách sâu hơn.','Tạo trải nghiệm','tốt hơn.','Và xây','những mối quan hệ','bền hơn.'],
'listen':['Nhưng khi một khách hàng','đang mệt mỏi,','ai sẽ ngồi xuống,','lắng nghe,','và hiểu điều họ','thực sự cần?'],
'care':['Một lời hỏi han','đúng lúc.','Một cách giải quyết','thấu tình.','Những điều nhỏ ấy','có thể khiến khách hàng','muốn quay lại.'],
'speed':['Lợi thế không dừng','ở ai làm','nhanh hơn.'],
'human':['Mà ở ai','dùng công nghệ','để hiểu con người','tốt hơn.'],
'agency':['AI không thay thế','con người.','Cách bạn dùng AI','mới tạo nên khác biệt.'],
'final':['Vậy, bạn sẽ dùng','phần thời gian','được giải phóng đó,','để làm gì?']}
def norm(x):return re.sub(r'[^\w]','',x).casefold()
for c in s['scenes']:
 pages=[];i=0
 for text in phrases[c['kind']]:
  chunks=text.split();words=c['words'][i:i+len(chunks)]
  assert [norm(x) for x in chunks]==[norm(w['text']) for w in words],(c['kind'],text,words)
  pages.append({'text':text,'start':words[0]['start'],'end':words[-1]['end'],'words':words});i+=len(chunks)
 assert i==len(c['words']),(c['kind'],i,len(c['words']))
 c['pages']=pages
p.write_text(json.dumps(s,ensure_ascii=False,indent=2))
print('Aligned',sum(len(c['pages']) for c in s['scenes']),'semantic text pages with real audio timings.')
