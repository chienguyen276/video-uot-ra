# AI — Cách mình dùng / Motion v2

Bản dựng lại theo phong cách video mẫu do người dùng cung cấp. Nguồn nội dung: **Mr. Namnguyen**, theo xác nhận của người dùng.

## Điểm thay đổi

- 9:16, 1080×1920, 30 fps; thời lượng khoảng 1 phút 18 giây.
- Lời đọc nhanh hơn 10% bằng xử lý tempo giữ nguyên cao độ; thời lượng giảm từ khoảng 86 giây xuống 78 giây.
- Thay bố cục xanh và tiêu đề cố định của bản trước bằng ảnh cắt ghép, nền kem–đen, chữ nhấn đỏ, các cụm chữ hiện theo lời, zoom nhấn và quét màn hình.
- 70 cụm chữ được chia theo ngữ nghĩa và căn theo dữ liệu thời gian từng từ của lời đọc. Mốc thời gian được biến đổi cùng hệ số tempo, không chia đều câu để giả thời gian từng từ.
- Nhạc mới ở 124 BPM: trống, bass có nhịp lệch, phím điện và hợp âm tổng hợp; tăng sự hiện diện của nhạc so với bản trước và tự hạ dưới giọng nói.
- Các điểm âm thanh gồm tiếng lướt/va chạm ở chuyển cảnh, tiếng gõ theo cụm chữ, tiếng giấy và tiếng đồng hồ. Xem `SOUND-DESIGN.json`.
- Ghi "Trích chia sẻ của Mr. Namnguyen" xuyên suốt, có tên rõ ở cảnh giới thiệu và phần kết.

## Nguồn hình và âm thanh

- Chỉ học cách dựng của video mẫu; không dùng lại cảnh quay, watermark, bản ghi âm hoặc nhạc từ video đó.
- Ảnh diễn giả do người dùng cung cấp từ phiên làm việc trước, đã tách nền; bản v2 bố cục lại và chuyển sang đen trắng.
- Laptop, đồng hồ, tập giấy và bắt tay là bộ ảnh cắt ghép được tạo mới bằng công cụ tạo ảnh.
- Các hình bóng, đồ họa vòng tròn, lưới và chữ được vẽ bằng mã.
- Lời dẫn vẫn là giọng tổng hợp biên tập của bản trước, không phải bản thu hoặc giọng được mô phỏng của Mr. Namnguyen.
- Nhạc và hiệu ứng được soạn/tổng hợp mới. Âm sắc phím và trống dùng TimGM6mb SoundFont có sẵn trong môi trường, không phân phối lại SoundFont trong gói này.
- Be Vietnam Pro theo SIL Open Font License; xem `FONT-LICENSE.txt`.

## Kết xuất lại

Cần Node.js và Chromium. `npm ci`, rồi `npm run render`. Script dùng Chromium tại `/usr/bin/chromium`; điều chỉnh đường dẫn nếu cần. `npm run studio` mở bản xem trước. Các tệp ảnh, phông, dữ liệu thời gian và âm thanh đã phối tại `public/` nên không cần dịch vụ bên ngoài để xuất lại phim.

`prepare_voice.py` ghi lại cách tăng tốc từ bản trước và cần dự án bản trước nếu chạy lại bước chuẩn bị đó; các tệp kết quả đã có sẵn nên không cần bước này để kết xuất. `make_audio.py` cần NumPy, SciPy, FFmpeg, libfluidsynth và SoundFont nếu muốn tạo lại nhạc từ đầu.

## Kiểm tra

Đã kiểm tra TypeScript, các khung hình ở 14 cảnh, các trạng thái chuyển ý, tên tác giả và cảnh kết. Âm thanh trước mã hóa khoảng -16.1 LUFS, đỉnh -2.9 dBTP. Phụ đề SRT dùng cùng dữ liệu thời gian với các cụm chữ trong phim.
