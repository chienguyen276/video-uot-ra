# AI — Cách mình dùng / Bản dựng theo video mẫu

## Brief
Rebuild the previous Vietnamese AI film in the visual grammar of the user's 25.4-second reference: kinetic phrases at the center, black/cream editorial collage, tactile photographic cutouts, red emphasis, punch zooms and meaningful wipe cuts. Preserve the article's core message. Narration approximately 10% faster with pitch preserved, tighter gaps, stronger original music and clearly audible but controlled motion sound effects. 9:16, 1080×1920, 30fps.

## Reference analysis
The reference alternates cream and black canvases; short central phrases reveal with speech; a single strong red keyword carries hierarchy. Cutout objects and silhouettes occupy corners/lower frame; fine grids and barcode motifs give editorial texture. Vertical split wipes and brief push-in accents connect shots. There are multiple staged reveals inside each shot, rather than one fixed headline and a lower caption line.

## Colors
#F8F3EC paper cream; #101010 near black; #E60024 editorial red; #6E6965 secondary gray. All photographic objects are mostly desaturated. No blue app tiles or business dashboard layouts from the previous film.

## Typography
Be Vietnam Pro 600/800. Central sentence fragments 60–66px, highlighted keywords 90–100px. A page carries 3–7 Vietnamese syllables, with punctuation and phrase boundaries; no long paragraph. Selected meaningful phrases get a 0.2s mask/punch entrance timed to the real spoken words. Keep critical text x=110..930, y=350..1500. Content attribution at y=1550.

## Motion
Expo-out arrivals, base unit .2s; short panel wipes between shots; match movements via shared object positioning; bounded punch zooms at emphasis markers. No strobes. Use a quieter dissolve for the listening beat. Photographic assets drift in parallax, but only one main visual action receives emphasis at a time.

## Audio
124-BPM original groovy electronic track, sampled drums and keys with analog-style chord stabs, syncopated bass and a recurring melody. Stronger musical presence than v1, with voice-controlled ducking and reduced upper mids for intelligibility. Foley-style accents for paper, clock, mouse, and graphic movement; stronger impact at core arguments. Silence/dropout around the listening beat.

## Attribution and assets
Credit source exactly as user requested: "Trích chia sẻ của Mr. Namnguyen" in the film, at the introduction and ending. Narration remains a newly synthesized editorial voice, not his event recording. Use the previously created speaker cutout. Other photographic objects are original image-generated assets, not copied from the reference; all collage animation and vector elements are new. Never reuse the reference video or its soundtrack in the deliverable.
