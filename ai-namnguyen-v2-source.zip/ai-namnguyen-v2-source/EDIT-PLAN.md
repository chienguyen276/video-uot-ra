# Lịch dựng — AI / Mr. Namnguyen / v2

124 BPM · 1080×1920 · 30 fps · 01:17.90

| Cảnh | Vào | Ra | Ý chính |
|---|---|---|---|
| 1 | 00:00.00 | 00:05.33 | AI CÓ GIÚP LẬT KÈO? |
| 2 | 00:05.33 | 00:10.63 | MỘT CÂU HỎI TẠI CICON |
| 3 | 00:10.63 | 00:15.97 | ĐÚNG HƯỚNG. NHANH HƠN. |
| 4 | 00:15.97 | 00:21.30 | ĐÚNG. NHƯNG CHƯA ĐỦ. |
| 5 | 00:21.30 | 00:27.10 | ĐỪNG CHỈ TỐI ƯU QUÁ KHỨ |
| 6 | 00:27.10 | 00:33.40 | HÃY ĐỔI CÂU HỎI |
| 7 | 00:33.40 | 00:40.63 | GIAO VIỆC LẶP LẠI CHO AI |
| 8 | 00:40.63 | 00:47.43 | ĐỂ CON NGƯỜI LÀM ĐIỀU QUAN TRỌNG |
| 9 | 00:47.43 | 00:53.23 | AI SẼ THỰC SỰ LẮNG NGHE? |
| 10 | 00:53.23 | 01:00.50 | SỰ QUAN TÂM TẠO KHÁC BIỆT |
| 11 | 01:00.50 | 01:03.40 | KHÔNG DỪNG Ở TỐC ĐỘ |
| 12 | 01:03.40 | 01:07.27 | CÔNG NGHỆ ĐỂ HIỂU CON NGƯỜI |
| 13 | 01:07.27 | 01:12.57 | CÁCH BẠN DÙNG MỚI KHÁC BIỆT |
| 14 | 01:12.57 | 01:17.90 | BẠN SẼ DÙNG THỜI GIAN ẤY LÀM GÌ? |
