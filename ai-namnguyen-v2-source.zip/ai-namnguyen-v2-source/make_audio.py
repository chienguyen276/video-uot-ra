from pathlib import Path
import ctypes as ct,ctypes.util,json,subprocess,math
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
r=Path(__file__).parent;p=r/'public';story=json.loads((p/'story.json').read_text());sr=44100;duration=story['durationInFrames']/30;N=round(duration*sr);beat=60/story['bpm'];bar=4*beat;rng=np.random.default_rng(2742026)
start={s['kind']:s['startFrame']/30 for s in story['scenes']};listen=start['listen'];care=start['care'];final=start['final']
fs=ct.CDLL(ctypes.util.find_library('fluidsynth'))
def api(n,rest,args):
 f=getattr(fs,n);f.restype=rest;f.argtypes=args;return f
P=ct.c_void_p;I=ct.c_int;D=ct.c_double;S=ct.c_char_p
settings=api('new_fluid_settings',P,[])();api('fluid_settings_setnum',I,[P,S,D])(settings,b'synth.sample-rate',sr);api('fluid_settings_setnum',I,[P,S,D])(settings,b'synth.gain',.65)
sy=api('new_fluid_synth',P,[P])(settings);api('fluid_synth_sfload',I,[P,S,I])(sy,b'/usr/share/sounds/sf2/TimGM6mb.sf2',1)
program=api('fluid_synth_program_change',I,[P,I,I]);program(sy,0,4);program(sy,1,89)
cc=api('fluid_synth_cc',I,[P,I,I,I]);cc(sy,0,7,65);cc(sy,1,7,35);cc(sy,9,7,108);cc(sy,0,10,50);cc(sy,1,10,79)
on=api('fluid_synth_noteon',I,[P,I,I,I]);off=api('fluid_synth_noteoff',I,[P,I,I]);write=api('fluid_synth_write_float',I,[P,I,P,I,I,P,I,I]);events=[]
chords=[[45,52,55,59,60],[41,48,52,55,57],[48,52,55,59,62],[43,50,57,59,62]]
def note(t,ch,k,v,length):
 if 0<=t<duration-.4:events.extend([(round(t*sr),1,ch,k,v),(min(N,round((t+length)*sr)),0,ch,k,0)])
for b in range(math.ceil(duration/bar)):
 t=b*bar;chord=chords[b%4]
 for k in chord[1:]:note(t,1,k+12,35,bar*1.1)
 for j,k in enumerate(chord[1:]):note(t+.035*j,0,k+12,55,bar*.82)
 if b%2:note(t+2.5*beat,0,chord[-1]+12,67,1.1)
for b in range(math.ceil(duration/beat)):
 t=b*beat;silent=listen<=t<care or t>final+1.3
 if silent:continue
 strength=.78 if care<=t<start['speed'] else 1
 note(t,9,36,round(112*strength),.18)
 if b%4 in [1,3]:note(t,9,39,round(91*strength),.2);note(t+.012,9,38,round(48*strength),.12)
 note(t+.53*beat,9,42,round((49+(b%3)*6)*strength),.08)
 note(t,9,42,round(25*strength),.055)
 if b%4==3:note(t+.76*beat,9,42,34,.05)
 if b%8==7:note(t+.5*beat,9,46,43,.20)
 if b%16==15 and t<listen-2:note(t+.75*beat,9,38,35,.08)
keys=np.zeros((N,2),np.float32);pos=0
for sample,kind,ch,k,v in sorted(events)+[(N,0,0,0,0)]:
 sample=min(sample,N)
 while pos<sample:
  n=min(4096,sample-pos);l=np.zeros(n,np.float32);rr=np.zeros(n,np.float32);write(sy,n,l.ctypes.data,0,1,rr.ctypes.data,0,1);keys[pos:pos+n]=np.stack([l,rr],axis=1);pos+=n
 if kind:on(sy,ch,k,v)
 else:off(sy,ch,k)
bus=np.zeros_like(keys);fx=np.zeros_like(keys);markers=[]
def add(dst,t,signal,amp=1,pan=.5):
 st=max(0,round(t*sr));en=min(N,st+len(signal))
 if en<=st:return
 v=np.asarray(signal[:en-st])*amp
 if v.ndim==1:dst[st:en,0]+=v*math.sqrt(1-pan);dst[st:en,1]+=v*math.sqrt(pan)
 else:dst[st:en]+=v

def bass(k,seconds=.38):
 tt=np.arange(round(seconds*sr))/sr;f=440*2**((k-69)/12)
 return np.tanh(1.7*(np.sin(2*np.pi*f*tt)+.32*np.sin(4*np.pi*f*tt)+.08*np.sin(6*np.pi*f*tt)))*(1-np.exp(-tt*140))*np.exp(-tt*6)
def stab(chord):
 tt=np.arange(round(.8*sr))/sr;sig=np.zeros(len(tt))
 for k in chord:
  f=440*2**((k+12-69)/12)
  for h,g in [(1,1),(2,.32),(3,.13),(5,.045)]:sig+=g*np.sin(2*np.pi*f*h*tt)*np.exp(-tt*(3.5+h*1.3))
 return sig/len(chord)*(1-np.exp(-tt*160))
def pluck(k):
 tt=np.arange(round(1.0*sr))/sr;f=440*2**((k-69)/12);return (np.sin(2*np.pi*f*tt)*np.exp(-tt*4)+.32*np.sin(4*np.pi*f*tt)*np.exp(-tt*10))*(1-np.exp(-tt*250))
melody=[69,72,76,79,76,72,74,71,69,67,72,76,74,71,67,69]
for b in range(math.ceil(duration/bar)):
 t=b*bar;chord=chords[b%4];breakdown=listen<=t<care;ending=t>final+1
 if not breakdown and not ending:
  for j,offbeat in enumerate([0,.75,1.5,2.5,3.25,3.75]):add(bus,t+offbeat*beat,bass(chord[0]-12+(12 if j==3 else 0)),.14 if j%2==0 else .10)
  for offbeat in [1.5,3.5]:
   wave=stab(chord[1:]);add(bus,t+offbeat*beat,wave,.085,pan=.3);add(bus,t+offbeat*beat+.022,wave,.055,pan=.8)
 if b%2==0 or breakdown:
  for j,offbeat in enumerate([.5,1.5,2.75]):
   k=melody[(b*2+j)%len(melody)];wave=pluck(k);amp=.045 if not breakdown else .04
   add(bus,t+offbeat*beat,wave,amp,pan=.36);add(bus,t+offbeat*beat+.27,wave,amp*.26,pan=.8)
# Audible motion design: whips, low impacts, paper rustles, clock ticks and tiny key taps.
def whoosh(length=.34):
 tt=np.arange(round(length*sr))/sr;noise=sosfilt(butter(2,[800,7000],fs=sr,btype='band',output='sos'),rng.normal(size=len(tt)));return noise*np.sin(np.pi*tt/length)**2

def pop():
 tt=np.arange(round(.11*sr))/sr;return np.sin(2*np.pi*(200*tt+240*.018*(1-np.exp(-tt/.018))))*np.exp(-tt*40)*(1-np.exp(-tt*600))
def tick():
 tt=np.arange(round(.045*sr))/sr;return (rng.normal(size=len(tt))*.3+np.sin(2*np.pi*1800*tt)) *np.exp(-tt*160)
def impact():
 tt=np.arange(round(.3*sr))/sr;return np.sin(2*np.pi*(52*tt+45*.025*(1-np.exp(-tt/.025))))*np.exp(-tt*16)*(1-np.exp(-tt*300))
for i,s in enumerate(story['scenes']):
 t=s['startFrame']/30
 if i and s['kind']!='listen':
  add(fx,t-.10,whoosh(),.063,pan=.55);add(fx,t+.015,impact(),.095);markers.append({'time':t,'type':'panel-whip-and-impact'})
 elif i:markers.append({'time':t,'type':'listening-dropout'})
 for j,page in enumerate(s['pages']):
  at=t+s['voiceOffsetFrames']/30+page['start']
  add(fx,at,tick(),.018,pan=.46+.10*(j%2));markers.append({'time':at,'type':'text-key-tap'})
  if j%2==0 and s['kind']!='listen':add(fx,at,pop(),.045,pan=.5)
 if s['kind'] in ['cost','past','routine']:
  for page in s['pages'][1::2]:
   at=t+s['voiceOffsetFrames']/30+page['start'];add(fx,at-.06,whoosh(.18),.033,pan=.3);markers.append({'time':at,'type':'paper-flick'})
 if s['kind'] in ['question','final']:
  for at in np.arange(t+.45,t+s['durationFrames']/30-.3,beat):add(fx,float(at),tick(),.028,pan=.52)
# Intro punctuation and musical release at the core human beat.
add(fx,.03,impact(),.12)
keys*=.055/(np.sqrt(np.mean(keys*keys))+1e-9);music=keys+bus
filtered=sosfilt(butter(2,[1400,4200],fs=sr,btype='bandstop',output='sos'),music,axis=0);music=.55*music+.45*filtered
music*=.075/(np.sqrt(np.mean(music*music))+1e-9)
fade=np.minimum(np.arange(N)/(sr*.12),1)*np.minimum((N-np.arange(N))/(sr*1.4),1);music*=fade[:,None]
voice=np.zeros(N,np.float32);sub=[]
for s in story['scenes']:
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p/s['audio']),'-f','f32le','-ac','1','-ar',str(sr),'-']);v=np.frombuffer(raw,np.float32).copy();v*=.12/(np.sqrt(np.mean(v*v))+1e-9)
 at=(s['startFrame']+s['voiceOffsetFrames'])/30;st=round(at*sr);en=min(N,st+len(v));voice[st:en]+=v[:en-st]
 for page in s['pages']:sub.append((at+page['start'],at+page['end'],page['text']))
env=np.convolve(np.abs(voice)[::441],np.ones(13)/13,mode='same');env=np.interp(np.arange(N)/441,np.arange(len(env)),env);duck=1-.43*np.clip(env/.065,0,1)
mix=voice[:,None]+music*duck[:,None]+fx
mix=np.tanh(mix*1.05)/1.05
wavfile.write(p/'mix-raw.wav',sr,np.int16(np.clip(mix,-1,1)*32767))
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'mix-raw.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=8','-ar',str(sr),str(p/'mix.wav')],check=True)
wavfile.write(r/'work/music-stem.wav',sr,np.int16(np.clip(music,-1,1)*32767));wavfile.write(r/'work/sfx-stem.wav',sr,np.int16(np.clip(fx,-1,1)*32767))
(r/'SOUND-DESIGN.json').write_text(json.dumps({'bpm':124,'markers':markers},indent=2))
def tc(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/ai-namnguyen-v2.vi.srt').write_text('\n\n'.join(f'{i+1}\n{tc(a)} --> {tc(b)}\n{text}' for i,(a,b,text) in enumerate(sub))+'\n')
print('Music rebuilt at 124 BPM;',len(markers),'timed sound markers; duration',duration,flush=True)
