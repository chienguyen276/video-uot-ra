from pathlib import Path
import json,subprocess,math
r=Path(__file__).parent;old=r.parent/'ai-human-film';s=json.loads((old/'public/story.json').read_text());speed=1.10;bpm=124;beat=60/bpm;cursor=0
for i,c in enumerate(s['scenes']):
 src=old/'public'/c['audio'];out=r/'public'/c['audio']
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(src),'-af',f'atempo={speed}','-c:a','libmp3lame','-q:a','1',str(out)],check=True)
 c['voiceDuration']=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(out)],text=True))
 for w in c['words']:w['start']/=speed;w['end']/=speed
 c['startFrame']=round(cursor*beat*30);c['voiceOffsetFrames']=5
 nbeats=math.ceil((c['voiceDuration']+.31)/beat)
 if c['kind']=='final':nbeats+=2
 cursor+=nbeats;c['durationFrames']=round(cursor*beat*30)-c['startFrame']
 print(c['kind'],c['startFrame']/30,c['durationFrames']/30)
s.update({'bpm':bpm,'durationInFrames':round(cursor*beat*30),'sourceCredit':'Mr. Namnguyen','voiceTempoMultiplier':speed})
(r/'public/story.json').write_text(json.dumps(s,ensure_ascii=False,indent=2))
print('TOTAL',s['durationInFrames']/30)
