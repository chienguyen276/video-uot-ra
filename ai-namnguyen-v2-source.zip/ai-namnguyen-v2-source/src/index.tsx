import React from 'react';import {Composition,registerRoot} from 'remotion';import {z} from 'zod';import {Film} from './Film';import s from '../public/story.json';
const schema=z.object({label:z.string()});
const Root=()=> <Composition id="AIReferenceV2" component={Film} fps={30} width={1080} height={1920} durationInFrames={s.durationInFrames} schema={schema} defaultProps={{label:'AI — Trích chia sẻ của Mr. Namnguyen'}}/>;registerRoot(Root);
